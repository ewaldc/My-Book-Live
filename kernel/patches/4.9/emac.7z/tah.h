/*
 * drivers/net/ethernet/ibm/emac/tah.h
 *
 * Driver for PowerPC 4xx on-chip ethernet controller, TAH support.
 *
 * Copyright 2007 Benjamin Herrenschmidt, IBM Corp.
 *                <benh@kernel.crashing.org>
 *
 * Based on the arch/ppc version of the driver:
 *
 * Copyright 2004 MontaVista Software, Inc.
 * Matt Porter <mporter@kernel.crashing.org>
 *
 * Copyright (c) 2005 Eugene Surovegin <ebs@ebshome.net>
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#ifndef __IBM_NEWEMAC_TAH_H
#define __IBM_NEWEMAC_TAH_H

/* TAH */
struct tah_regs {
	u32 revid;
	u32 pad[3];
	u32 mr;
	u32 ssr0;
	u32 ssr1;
	u32 ssr2;
	u32 ssr3;
	u32 ssr4;
	u32 ssr5;
	u32 tsr;
};


/* TAH device */
/* Default MTU values for common networks. Note that the first value may not correct as 
 * we will use the device's current MTU for SSR0 */
#define TAH_SS_DEFAULT_9K	{9000, 4080, 1500, 1006, 576, 68}
#define TAH_SS_DEFAULT_4K	{4080, 1500, 1400, 1006, 576, 68}
#define TAH_SS_DEFAULT		{1500, 1400, 1280, 1006, 576, 68}

#define TAH_NO_SSR	6
struct tah_instance {
	struct tah_regs __iomem	*base;

	u32 			ssr[TAH_NO_SSR];	// Current setting for TAHx_SSRx
	//u32 			ssr_order[TAH_NO_SSR];	// Indexes of ordered TAH_x_SSRx values, high to low

	struct mutex		lock;	// Only one EMAC whacks us at a time
	int			users;	// number of EMACs using this TAH
	struct platform_device	*ofdev;	// OF device instance
};

/* TAH engine */
#define TAH_MR_CVR		0x80000000
#define TAH_MR_SR		0x40000000
#define TAH_MR_ST_256		0x01000000
#define TAH_MR_ST_512		0x02000000
#define TAH_MR_ST_768		0x03000000
#define TAH_MR_ST_1024		0x04000000
#define TAH_MR_ST_1280		0x05000000
#define TAH_MR_ST_1536		0x06000000
#define TAH_MR_TFS_16KB		0x00000000
#define TAH_MR_TFS_2KB		0x00200000
#define TAH_MR_TFS_4KB		0x00400000
#define TAH_MR_TFS_6KB		0x00600000
#define TAH_MR_TFS_8KB		0x00800000
#define TAH_MR_TFS_10KB		0x00a00000
#define TAH_MR_DTFP		0x00100000
#define TAH_MR_DIG		0x00080000
#define TAH_SSR_2_SS(val)	(((val) >> 17) & 0x1fff)
#define SS_2_TAH_SSR(s)		(((s) & 0x1fff) << 17) 		// s is number of half words

#ifdef CONFIG_IBM_EMAC_TAH

int tah_init(void);
void tah_exit(void);
int tah_attach(struct platform_device *ofdev, int channel);
void tah_detach(struct platform_device *ofdev, int channel);
void tah_reset(struct platform_device *ofdev);
int tah_get_regs_len(struct platform_device *ofdev);
void *tah_dump_regs(struct platform_device *ofdev, void *buf);
void tah_set_ssr(struct platform_device *ofdev, int index, int seg_size);
u32 tah_get_ssr(struct platform_device *ofdev, int index);

#else

# define tah_init()		0
# define tah_exit()		do { } while(0)
# define tah_attach(x,y)	(-ENXIO)
# define tah_detach(x,y)	do { } while(0)
# define tah_reset(x)		do { } while(0)
# define tah_get_regs_len(x)	0
# define tah_dump_regs(x,buf)	(buf)

#endif	/* !CONFIG_IBM_EMAC_TAH */

#endif /* __IBM_NEWEMAC_TAH_H */
