/*
 * drivers/net/ethernet/ibm/emac/mal.h
 *
 * Memory Access Layer (MAL) support
 *
 * Copyright 2007 Benjamin Herrenschmidt, IBM Corp.
 *                <benh@kernel.crashing.org>
 *
 * Based on the arch/ppc version of the driver:
 *
 * Copyright (c) 2004, 2005 Zultys Technologies.
 * Eugene Surovegin <eugene.surovegin@zultys.com> or <ebs@ebshome.net>
 *
 * Based on original work by
 *      Armin Kuster <akuster@mvista.com>
 *      Copyright 2002 MontaVista Softare Inc.
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */
#ifndef __IBM_NEWEMAC_MAL_H
#define __IBM_NEWEMAC_MAL_H

/*
 * There are some variations on the MAL, we express them in this driver as
 * MAL Version 1 and 2 though that doesn't match any IBM terminology.
 *
 * We call MAL 1 the version in 405GP, 405GPR, 405EP, 440EP, 440GR and
 * NP405H.
 *
 * We call MAL 2 the version in 440GP, 440GX, 440SP, 440SPE and Axon
 *
 * The driver expects a "version" property in the emac node containing
 * a number 1 or 2. New device-trees for EMAC capable platforms are thus
 * required to include that when porting to arch/powerpc.
 */

/* MALx DCR registers */
#define	MAL_CFG 		0x00
#define	MAL_CFG_SR  		0x80000000
#define MAL_CFG_PLBB		0x00004000
#define MAL_CFG_OPBBL		0x00000080
#define MAL_CFG_EOPIE		0x00000004
#define MAL_CFG_LEA	    	0x00000002
#define MAL_CFG_SD	    	0x00000001

/* MAL V1 CFG bits */
#define MAL1_CFG_PLBP_MASK	0x00c00000
#define MAL1_CFG_PLBP_10	0x00800000
#define MAL1_CFG_GA	    	0x00200000
#define MAL1_CFG_OA	    	0x00100000
#define MAL1_CFG_PLBLE  	0x00080000
#define MAL1_CFG_PLBT_MASK	0x00078000
#define MAL1_CFG_DEFAULT	(MAL1_CFG_PLBP_10 | MAL1_CFG_PLBT_MASK)

/* MAL V2 CFG bits */
#define MAL2_CFG_RPP_MASK	0x00c00000
#define MAL2_CFG_RPP_10	   	0x00800000
#define MAL2_CFG_RMBS_MASK	0x00300000
#define MAL2_CFG_WPP_MASK	0x000c0000
#define MAL2_CFG_WPP_10	   	0x00080000
#define MAL2_CFG_WMBS_MASK	0x00030000
#define MAL2_CFG_PLBLE	   	0x00008000
#define MAL2_CFG_DEFAULT	(MAL2_CFG_RMBS_MASK | MAL2_CFG_WMBS_MASK | \
				 MAL2_CFG_RPP_10 | MAL2_CFG_WPP_10)

#define MAL_ESR			0x01
#define MAL_ESR_EVB		0x80000000
#define MAL_ESR_CIDT		0x40000000
#define MAL_ESR_CID_MASK	0x3e000000
#define MAL_ESR_CID_SHIFT	25
#define MAL_ESR_DE		0x00100000
#define MAL_ESR_OTE		0x00040000
#define MAL_ESR_OSE		0x00020000
#define MAL_ESR_PEIN		0x00010000
#define MAL_ESR_DEI		0x00000010
#define MAL_ESR_OTEI		0x00000004
#define MAL_ESR_OSEI		0x00000002
#define MAL_ESR_PBEI		0x00000001

/* MAL V1 ESR bits */
#define MAL1_ESR_ONE		0x00080000
#define MAL1_ESR_ONEI		0x00000008

/* MAL V2 ESR bits */
#define MAL2_ESR_PTE		0x00800000
#define MAL2_ESR_PRE		0x00400000
#define MAL2_ESR_PWE		0x00200000
#define MAL2_ESR_PTEI		0x00000080
#define MAL2_ESR_PREI		0x00000040
#define MAL2_ESR_PWEI		0x00000020

#define MAL_IER			0x02
/* MAL IER bits */
#define MAL_IER_DE		0x00000010
#define MAL_IER_OTE		0x00000004
#define MAL_IER_OE		0x00000002
#define MAL_IER_PE		0x00000001

/* PLB read/write/timeout errors */
#define MAL_IER_PTE		0x00000080
#define MAL_IER_PRE		0x00000040
#define MAL_IER_PWE		0x00000020

#define MAL_IER_SOC_EVENTS	(MAL_IER_PTE | MAL_IER_PRE | MAL_IER_PWE)
#define MAL_IER_EVENTS	    	(MAL_IER_SOC_EVENTS | MAL_IER_DE | MAL_IER_OTE | MAL_IER_OE | MAL_IER_PE)

#define MAL_TXCASR		0x04
#define MAL_TXCARR		0x05
#define MAL_TXEOBISR		0x06
#define MAL_TXDEIR		0x07
#define MAL_TXBADDR		0x09
#define MAL_RXCASR		0x10
#define MAL_RXCARR		0x11
#define MAL_RXEOBISR		0x12
#define MAL_RXDEIR		0x13
#define MAL_RXBADDR		0x15
#define MAL_TXCTPR(n)		((n) + 0x20)
#define MAL_RXCTPR(n)		((n) + 0x40)
#define MAL_RCBS(n)		((n) + 0x60)

/* In reality MAL can handle TX buffers up to 4095 bytes long,
 * but this isn't a good round number :) --ebs */
#define MAL_MAX_TX_SIZE		4080
#define MAL_MAX_RX_SIZE		4080

static inline int mal_rx_size(int len) {
	len = (len + 0xf) & ~0xf;
	return len > MAL_MAX_RX_SIZE ? MAL_MAX_RX_SIZE : len;
}

/* Since MAL_MAX_TX_SIZE is close to 4K, this is a good-enough esimate */
#define MAL_ESTIMATE_TX_CHUNKS(len) (len >> 12)
static inline int mal_tx_chunks(int len) {
    return DIV_ROUND_UP(len, MAL_MAX_TX_SIZE);
}

#define MAL_CHAN_MASK(n)	(0x80000000 >> (n))

/* MAL Buffer Descriptor structure */
struct mal_descriptor {
	u16 ctrl;		/* MAL / Commac status control bits */
	u16 data_len;		/* Max length is 4K-1 (12 bits)     */
	u32 data_ptr;		/* pointer to actual data buffer    */
};

/* the following defines are for the MadMAL status and control registers. */
/* MADMAL transmit and receive status/control bits  */
#define MAL_RX_CTRL_EMPTY	0x8000
#define MAL_RX_CTRL_WRAP	0x4000
#define MAL_RX_CTRL_CM		0x2000
#define MAL_RX_CTRL_LAST	0x1000
#define MAL_RX_CTRL_FIRST	0x0800
/* Optimize OR operations */ // ECO
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
#define MAL_RX_CTRL_INTR	0x0400
#else
#define MAL_RX_CTRL_INTR	0x0
#endif

#define MAL_RX_CTRL_SINGLE	(MAL_RX_CTRL_LAST | MAL_RX_CTRL_FIRST)
#define MAL_IS_SINGLE_RX(ctrl)	(((ctrl) & MAL_RX_CTRL_SINGLE) == MAL_RX_CTRL_SINGLE)

#define MAL_TX_CTRL_READY	0x8000
#define MAL_TX_CTRL_WRAP	0x4000
#define MAL_TX_CTRL_CM		0x2000
#define MAL_TX_CTRL_LAST	0x1000
#define MAL_TX_CTRL_INTR	0x0400

#define MAL_DESC_MEM_SDRAM	0x0
#define MAL_DESC_MEM_OCM	0x1

#if defined(CONFIG_405EX)
#define DCRN_SDR0_ICCRTX	0x430B /* Int coal Tx control register */
#define DCRN_SDR0_ICCRRX	0x430C /* Int coal Rx control register */
#define SDR0_ICC_FTHR0_SHIFT 	23
#define SDR0_ICC_FLUSH0		22
#define SDR0_ICC_FLUWI0		21
#define SDR0_ICC_FTHR1_SHIFT 	12
#define SDR0_ICC_FLUSH1		11
#define SDR0_ICC_FLUWI1		10
#define DCRN_SDR0_ICCTRTX0	0x430D /* Int coal Tx0 count threshold */
#define DCRN_SDR0_ICCTRTX1	0x430E /* Int coal Tx1 count threshold */
#define DCRN_SDR0_ICCTRRX0	0x430F /* Int coal Rx0 count threshold */
#define DCRN_SDR0_ICCTRRX1	0x4310 /* Int coal Rx1 count threshold */
#define DCRN_SDR0_ICTSRTX0	0x4307 /* Int coal Tx0 timer status*/
#define DCRN_SDR0_ICTSRTX1	0x4308 /* Int coal Tx1 timer status*/
#define DCRN_SDR0_ICTSRRX0	0x4309 /* Int coal Rx0 timer status*/
#define DCRN_SDR0_ICTSRRX1	0x430A /* Int coal Rx1 timer status*/

#elif defined(CONFIG_APM821xx)
#define DCRN_SDR0_ICCRTX0	0x4410 /* Int coal Tx0 control register */
#define DCRN_SDR0_ICCRRX0	0x4414 /* Int coal Rx0 control register */
#define SDR0_ICC_FTHR_SHIFT	23
#define SDR0_ICC_FLUSH		22
#define SDR0_ICC_FLUWI		21
#define DCRN_SDR0_ICCTRTX0	0x4418 /* Int coal Tx0 count threshold */
#define DCRN_SDR0_ICCTRRX0	0x441C /* Int coal Rx0 count threshold */
#define DCRN_SDR0_ICTSRTX0	0x4420 /* Int coal Tx0 timer status*/
#define DCRN_SDR0_ICTSRRX0	0x4424 /* Int coal Rx0 timer status*/
#define SDR0_PERCLK		0x4201

#define DCRN_SDR0_MIRQ0		0x0260
#define DCRN_SDR0_MIRQ1		0x0261
#define DCRN_SDR0_MALTBL	0x0280 /* MAL Transmit Burst Length */
#define DCRN_SDR0_MALRBL	0x02A0 /* MAL Receive Burst Length */
#define DCRN_SDR0_MALTBS	0x02C0 /* MAL Transmit Bus Size */
#define DCRN_SDR0_MALRBS	0x02E0 /* MAL Receive Bus Size */

#elif defined(CONFIG_460EX) || defined(CONFIG_460GT) || defined(CONFIG_460SX)
#define DCRN_SDR0_ICCRTX0	0x4410 /* Int coal Tx0 control register */
#define DCRN_SDR0_ICCRTX1	0x4411 /* Int coal Tx1 control register */
#define DCRN_SDR0_ICCRTX2	0x4412 /* Int coal Tx2 control register */
#define DCRN_SDR0_ICCRTX3	0x4413 /* Int coal Tx3 control register */
#define DCRN_SDR0_ICCRRX0	0x4414 /* Int coal Rx0 control register */
#define DCRN_SDR0_ICCRRX1	0x4415 /* Int coal Rx1 control register */
#define DCRN_SDR0_ICCRRX2	0x4416 /* Int coal Rx2 control register */
#define DCRN_SDR0_ICCRRX3	0x4417 /* Int coal Rx3 control register */
#define SDR0_ICC_FTHR_SHIFT	23
#define SDR0_ICC_FLUSH		22
#define SDR0_ICC_FLUWI		21
#define DCRN_SDR0_ICCTRTX0	0x4418 /* Int coal Tx0 count threshold */
#define DCRN_SDR0_ICCTRTX1	0x4419 /* Int coal Tx1 count threshold */
#define DCRN_SDR0_ICCTRTX2	0x441A /* Int coal Tx2 count threshold */
#define DCRN_SDR0_ICCTRTX3	0x441B /* Int coal Tx3 count threshold */
#define DCRN_SDR0_ICCTRRX0	0x441C /* Int coal Rx0 count threshold */
#define DCRN_SDR0_ICCTRRX1	0x441D /* Int coal Rx1 count threshold */
#define DCRN_SDR0_ICCTRRX2	0x441E /* Int coal Rx2 count threshold */
#define DCRN_SDR0_ICCTRRX3	0x441F /* Int coal Rx3 count threshold */
#define DCRN_SDR0_ICTSRTX0	0x4420 /* Int coal Tx0 timer status*/
#define DCRN_SDR0_ICTSRTX1	0x4421 /* Int coal Tx1 timer status*/
#define DCRN_SDR0_ICTSRTX2	0x4422 /* Int coal Tx2 timer status*/
#define DCRN_SDR0_ICTSRTX3	0x4423 /* Int coal Tx3 timer status*/
#define DCRN_SDR0_ICTSRRX0	0x4424 /* Int coal Rx0 timer status*/
#define DCRN_SDR0_ICTSRRX1	0x4425 /* Int coal Rx1 timer status*/
#define DCRN_SDR0_ICTSRRX2	0x4426 /* Int coal Rx2 timer status*/
#define DCRN_SDR0_ICTSRRX3	0x4427 /* Int coal Rx3 timer status*/
#endif

#define COAL_FRAME_MASK		0x1FF
#define MAL_MAX_PHYS_CHANNELS	4

struct mal_commac_ops {
	void	(*poll_tx) (void *dev);
	int	(*poll_rx) (void *dev, int budget);
	int	(*peek_rx) (void *dev);
	void	(*rxde) (void *dev);
};
struct mal_commac {
	struct mal_commac_ops	*ops;
	void			*dev;
#if !defined (CONFIG_APM821xx)
	struct list_head	poll_list;
	struct list_head	list;
#endif
	long       		flags;
#define MAL_COMMAC_RX_STOPPED		0
#define MAL_COMMAC_POLL_DISABLED	1
	u32			tx_chan_mask;
	u32			rx_chan_mask;
};

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
struct mal_coales_param { /* Configuration parameters for the coalescing function */
	int         tx_count;
	int         tx_time;
	int         rx_count;
	int         rx_time;
};
#endif

struct mal_instance {
	int			version;
	dcr_host_t		dcr_host;
	int			desc_memory;	/* SDRAM or OCM */
	int			num_tx_chans;	/* Number of TX channels */
	int			num_rx_chans;	/* Number of RX channels */
	int 			txeob_irq;	/* TX End Of Buffer IRQ  */
	int 			rxeob_irq;	/* RX End Of Buffer IRQ  */
	int			txde_irq;	/* TX Descriptor Error IRQ */
	int			rxde_irq;	/* RX Descriptor Error IRQ */
	int			serr_irq;	/* MAL System Error IRQ    */

#if defined(CONFIG_IBM_EMAC_INTR_COALESCE)
	int			txcoal0_irq;	/* COAL */
	int			txcoal1_irq;	/* COAL */
	int			txcoal2_irq;	/* COAL */
	int			txcoal3_irq;	/* COAL */
	int			rxcoal0_irq;	/* COAL */
	int			rxcoal1_irq;	/* COAL */
	int			rxcoal2_irq;	/* COAL */
	int			rxcoal3_irq;	/* COAL */

	struct mal_coales_param coales_param[4];
	/* add copy of iccrtx and iccrrx registers to bypass the bug on the 440EPX pass1 
	 * where these registers are write only */
	u32     	enet_coales_iccrtx;
	u32     	enet_coales_iccrrx;
	struct timer_list mal_coal_timer;
#endif

	struct napi_struct	napi;

#if defined (CONFIG_APM821xx)
    struct mal_commac  *poll_commac;
    struct mal_commac  *commac;
    u32         poll_tx;
    u32         poll_rx;
#else
	struct list_head	poll_list;
	struct list_head	list;
#endif
	u32			tx_chan_mask;
	u32			rx_chan_mask;

	dma_addr_t		bd_dma;
	phys_addr_t		bd_phys;
	struct mal_descriptor	*bd_virt;

	struct platform_device	*ofdev;
	int			index;
	spinlock_t		lock;

	struct net_device	dummy_dev;

	unsigned int features;
	u32			net_alloc_offset;
    u32         mal_cfg;    /* Cache mal CFG */
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	int			txcoal_irq[MAL_MAX_PHYS_CHANNELS];	/* MAL TxCoalesce Error IRQ    */
	int			rxcoal_irq[MAL_MAX_PHYS_CHANNELS];	/* MAL RxCoalesce IRQ    */
	int			coalesce_disabled;	/* Coalesce disable flag    */
#endif
};

static inline u32 get_mal_dcrn(struct mal_instance *mal, int reg) {
	return dcr_read(mal->dcr_host, reg);
}

static inline void set_mal_dcrn(struct mal_instance *mal, int reg, u32 val){
	dcr_write(mal->dcr_host, reg, val);
}

/* Features of various MAL implementations */

/* Set if you have interrupt coalescing and you have to clear the SDR
 * register for TXEOB and RXEOB interrupts to work */
#define MAL_FTR_CLEAR_ICINTSTAT	0x00000001

/* Set if your MAL has SERR, TXDE, and RXDE OR'd into a single UIC interrupt */
#define MAL_FTR_COMMON_ERR_INT	0x00000002

enum {
	MAL_FTRS_ALWAYS = 0,
	MAL_FTRS_POSSIBLE =
#ifdef CONFIG_IBM_EMAC_MAL_CLR_ICINTSTAT
	MAL_FTR_CLEAR_ICINTSTAT |
#endif
#ifdef CONFIG_IBM_EMAC_MAL_COMMON_ERR
	MAL_FTR_COMMON_ERR_INT |
#endif
	0,
};

static inline int mal_has_feature(struct mal_instance *dev, unsigned long feature) {
	return (MAL_FTRS_ALWAYS & feature) || (MAL_FTRS_POSSIBLE & dev->features & feature);
}

/* Register MAL devices */
int mal_init(void);
void mal_exit(void);

int mal_register_commac(struct mal_instance *mal, struct mal_commac *commac);
void mal_unregister_commac(struct mal_instance *mal, struct mal_commac *commac);
int mal_set_rcbs(struct mal_instance *mal, int channel, unsigned long size);

/* Returns BD ring offset for a particular channel (in 'struct mal_descriptor' elements)*/
int mal_tx_bd_offset(struct mal_instance *mal, int channel);
int mal_rx_bd_offset(struct mal_instance *mal, int channel);

void mal_enable_tx_channel(struct mal_instance *mal, int channel);
void mal_disable_tx_channel(struct mal_instance *mal, int channel);
void mal_enable_rx_channel(struct mal_instance *mal, int channel);
void mal_disable_rx_channel(struct mal_instance *mal, int channel);

void mal_poll_disable(struct mal_instance *mal, struct mal_commac *commac);
void mal_poll_enable(struct mal_instance *mal, struct mal_commac *commac);
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
void mal_enable_coal(struct mal_instance *mal);
#endif

/* Add/remove EMAC to/from MAL polling list */
void mal_poll_add(struct mal_instance *mal, struct mal_commac *commac);
void mal_poll_del(struct mal_instance *mal, struct mal_commac *commac);

/* Ethtool MAL registers */
struct mal_regs {
	u32 tx_count;
	u32 rx_count;
	u32 cfg;
	u32 esr;
	u32 ier;
	u32 tx_casr;
	u32 tx_carr;
	u32 tx_eobisr;
	u32 tx_deir;
	u32 rx_casr;
	u32 rx_carr;
	u32 rx_eobisr;
	u32 rx_deir;
	u32 tx_ctpr[32];
	u32 rx_ctpr[32];
	u32 rcbs[32];
};

int mal_get_regs_len(struct mal_instance *mal);
void *mal_dump_regs(struct mal_instance *mal, void *buf);

#endif /* __IBM_NEWEMAC_MAL_H */
