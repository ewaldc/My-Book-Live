/*
 * drivers/net/ethernet/ibm/emac/mal.c
 *
 * Memory Access Layer (MAL) support
 *
 * Copyright 2007 Benjamin Herrenschmidt, IBM Corp.
 *                <benh@kernel.crashing.org>
 *
 * Based on the arch/ppc version of the driver:
 *
 * Copyright (c) 2004, 2005 Zultys Technologies.
 * Eugene Surovegin <eugene.surovegin@zultys.com> or <ebs@ebshome.net>
 *
 * Based on original work by
 *      Benjamin Herrenschmidt <benh@kernel.crashing.org>,
 *      David Gibson <hermes@gibson.dropbear.id.au>,
 *
 *      Armin Kuster <akuster@mvista.com>
 *      Copyright 2002 MontaVista Softare Inc.
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */

#include "core.h"
#include "mal.h"
#include <asm/dcr-regs.h>
#include <asm/ppc4xx_ocm.h>

static int mal_count;
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
static char *tx_coal_irqname[] = {"TX0 COAL", "TX1 COAL", "TX2 COAL", "TX3 COAL",};
static char *rx_coal_irqname[] = {"RX0 COAL", "RX1 COAL", "RX2 COAL", "RX3 COAL",};
#endif

#ifdef CONFIG_IBM_EMAC_MASK_CEXT
extern void emac_start_idlemode(struct emac_instance *dev);
#endif

int mal_register_commac(struct mal_instance *mal, struct mal_commac *commac) {
	unsigned long flags;

	spin_lock_irqsave(&mal->lock, flags);

	MAL_DBG(mal, "reg(%08x, %08x)" NL, commac->tx_chan_mask, commac->rx_chan_mask);

	/* Don't let multiple commacs claim the same channel(s) */
	if ((mal->tx_chan_mask & commac->tx_chan_mask) || (mal->rx_chan_mask & commac->rx_chan_mask)) {
		spin_unlock_irqrestore(&mal->lock, flags);
		printk(KERN_WARNING "mal%d: COMMAC channels conflict!\n", mal->index);
		return -EBUSY;
	}

	mal->tx_chan_mask |= commac->tx_chan_mask;
	mal->rx_chan_mask |= commac->rx_chan_mask;

#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
	napi_enable(&mal->napi);
    mal->commac = commac;
#else
	if (list_empty(&mal->list)) napi_enable(&mal->napi);
	list_add(&commac->list, &mal->list);
#endif
	spin_unlock_irqrestore(&mal->lock, flags);
	return 0;
}

void mal_unregister_commac(struct mal_instance	*mal, struct mal_commac *commac) {
	unsigned long flags;

	spin_lock_irqsave(&mal->lock, flags);
	MAL_DBG(mal, "unreg(%08x, %08x)" NL, commac->tx_chan_mask, commac->rx_chan_mask);

	mal->tx_chan_mask &= ~commac->tx_chan_mask;
	mal->rx_chan_mask &= ~commac->rx_chan_mask;

#if defined(CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    mal->commac = NULL;
    napi_disable(&mal->napi);
#else
	list_del_init(&commac->list);
	if (list_empty(&mal->list))	napi_disable(&mal->napi);
#endif
	spin_unlock_irqrestore(&mal->lock, flags);
}

int mal_set_rcbs(struct mal_instance *mal, int channel, unsigned long size) {
	BUG_ON(channel < 0 || channel >= mal->num_rx_chans || size > MAL_MAX_RX_SIZE);
	MAL_DBG(mal, "set_rbcs(%d, %lu)" NL, channel, size);
	if (size & 0xf) {
		printk(KERN_WARNING "mal%d: incorrect RX size %lu for the channel %d\n",
		       mal->index, size, channel);
		return -EINVAL;
	}
	set_mal_dcrn(mal, MAL_RCBS(channel), size >> 4);
	return 0;
}

int mal_tx_bd_offset(struct mal_instance *mal, int channel) {
	BUG_ON(channel < 0 || channel >= mal->num_tx_chans);
	return channel * NUM_TX_BUFF;
}

int mal_rx_bd_offset(struct mal_instance *mal, int channel) {
	BUG_ON(channel < 0 || channel >= mal->num_rx_chans);
	return mal->num_tx_chans * NUM_TX_BUFF + channel * NUM_RX_BUFF;
}

void mal_enable_tx_channel(struct mal_instance *mal, int channel) {
	unsigned long flags;

	spin_lock_irqsave(&mal->lock, flags);
	MAL_DBG(mal, "enable_tx(%d)" NL, channel);
	set_mal_dcrn(mal, MAL_TXCASR, get_mal_dcrn(mal, MAL_TXCASR) | MAL_CHAN_MASK(channel));
	spin_unlock_irqrestore(&mal->lock, flags);
}

void mal_disable_tx_channel(struct mal_instance *mal, int channel) {
	set_mal_dcrn(mal, MAL_TXCARR, MAL_CHAN_MASK(channel));
	MAL_DBG(mal, "disable_tx(%d)" NL, channel);
}

void mal_enable_rx_channel(struct mal_instance *mal, int channel) {
	/* On some 4xx PPC's (e.g. 460EX/GT), the rx channel is a multiple of 8,
	 * but enabling in MAL_RXCASR needs dividing by 8 value for the bitmask */
	unsigned long flags;
	if (!(channel % 8)) channel >>= 3;

	spin_lock_irqsave(&mal->lock, flags);
	MAL_DBG(mal, "enable_rx(%d)" NL, channel);
	set_mal_dcrn(mal, MAL_RXCASR, get_mal_dcrn(mal, MAL_RXCASR) | MAL_CHAN_MASK(channel));
	spin_unlock_irqrestore(&mal->lock, flags);
}

void mal_disable_rx_channel(struct mal_instance *mal, int channel) {
	/* On some 4xx PPC's (e.g. 460EX/GT), the rx channel is a multiple of 8,
	 * but enabling in MAL_RXCASR needs dividing by 8 value for the bitmask */
	if (!(channel % 8)) channel >>= 3;
	set_mal_dcrn(mal, MAL_RXCARR, MAL_CHAN_MASK(channel));
	MAL_DBG(mal, "disable_rx(%d)" NL, channel);
}

void mal_poll_add(struct mal_instance *mal, struct mal_commac *commac) {
	unsigned long flags;

	spin_lock_irqsave(&mal->lock, flags);
	MAL_DBG(mal, "poll_add(%p)" NL, commac);
	set_bit(MAL_COMMAC_POLL_DISABLED, &commac->flags);	/* starts disabled */

#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    mal->poll_commac = commac;
#else
	list_add_tail(&commac->poll_list, &mal->poll_list);
#endif
	spin_unlock_irqrestore(&mal->lock, flags);
}

void mal_poll_del(struct mal_instance *mal, struct mal_commac *commac) {
	unsigned long flags;

	spin_lock_irqsave(&mal->lock, flags);
	MAL_DBG(mal, "poll_del(%p)" NL, commac);

#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    mal->poll_commac = NULL;
#else
	list_del(&commac->poll_list);
#endif
	spin_unlock_irqrestore(&mal->lock, flags);
}

/* synchronized by mal_poll() */
static __always_inline void mal_enable_eob_irq(struct mal_instance *mal) {
	MAL_DBG2(mal, "enable_irq" NL);
	// Cache MAL_CFG as the DCR read can be slooooow
	//set_mal_dcrn(mal, MAL_CFG, get_mal_dcrn(mal, MAL_CFG) | MAL_CFG_EOPIE);
	set_mal_dcrn(mal, MAL_CFG, mal->mal_cfg | MAL_CFG_EOPIE);  
}

/* synchronized by NAPI state */
static __always_inline void mal_disable_eob_irq(struct mal_instance *mal) {
	// Cache MAL_CFG as the DCR read can be slooooow
	//set_mal_dcrn(mal, MAL_CFG, get_mal_dcrn(mal, MAL_CFG) & ~MAL_CFG_EOPIE);
	set_mal_dcrn(mal, MAL_CFG, mal->mal_cfg & ~MAL_CFG_EOPIE);  
	MAL_DBG2(mal, "disable_irq" NL);
}

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
#if defined(CONFIG_460SX)
/* Set Tx fram count */
static void set_ic_txfthr(struct mal_instance *mal) {
	int val = (mal->coales_param[0].tx_count) << SDR0_ICC_FTHR_SHIFT;
	int reg = val | (1<<SDR0_ICC_FLUSH);  // Flush bit 1 enables counter

	SDR_WRITE(DCRN_SDR0_ICCRTX0, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX0, val);	/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX1, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX1, val);	/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX2, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX2, val);	/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX3, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRTX3, val);	/* enable counter */
	mal->enet_coales_iccrtx = reg;
}
/* Set Rx fram count */
static void set_ic_rxfthr(struct mal_instance *mal) {
	int val = (mal->coales_param[0].rx_count) << SDR0_ICC_FTHR_SHIFT;
	int reg = val | (1<<SDR0_ICC_FLUSH);  // Flush bit 1 enables counter

	SDR_WRITE(DCRN_SDR0_ICCRRX0, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX0, val);/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX1, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX1, val);/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX2, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX2, val);/* enable counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX3, reg);	/* set counter */
	SDR_WRITE(DCRN_SDR0_ICCRRX3, val);/* enable counter */
	mal->enet_coales_iccrrx = reg;
}
#endif

#define TX_COAL_CNT (CONFIG_IBM_EMAC_TX_COAL_COUNT & COAL_FRAME_MASK)
#define RX_COAL_CNT (CONFIG_IBM_EMAC_RX_COAL_COUNT & COAL_FRAME_MASK)

inline void mal_enable_coal(struct mal_instance *mal) {
#if defined(CONFIG_405EX)
	/* Clear the counters */
	mtdcri(SDR0, DCRN_SDR0_ICCRTX, SDR0_ICC_FLUSH0 | SDR0_ICC_FLUSH1);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX, SDR0_ICC_FLUSH0 | SDR0_ICC_FLUSH1);

	/* Set Tx/Rx Timer values */
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX0, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX1, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX0, CONFIG_IBM_EMAC_RX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX1, CONFIG_IBM_EMAC_RX_COAL_TIMER);

	/* Enable the Tx/Rx Coalescing interrupt */
	mtdcri(SDR0, DCRN_SDR0_ICCRTX, (TX_COAL_CNT<<SDR0_ICC_FTHR0_SHIFT)|(TX_COAL_CNT<<SDR0_ICC_FTHR1_SHIFT));
	mtdcri(SDR0, DCRN_SDR0_ICCRRX, (RX_COAL_CNT<<SDR0_ICC_FTHR0_SHIFT)|(RX_COAL_CNT<<SDR0_ICC_FTHR1_SHIFT));
#elif defined(CONFIG_APM821xx)
	/* Clear the counters */
	//val = SDR0_ICC_FLUSH;
	mtdcri(SDR0, DCRN_SDR0_ICCRTX0, SDR0_ICC_FLUSH);	//val
	mtdcri(SDR0, DCRN_SDR0_ICCRRX0, SDR0_ICC_FLUSH);	//val

	/* Set Tx/Rx Timer values, with SYSFS the user can change those */
#if defined(CONFIG_IBM_EMAC_SYSFS)
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX0, mal->coales_param[0].tx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX0, mal->coales_param[0].rx_time);
	/* Enable the Tx/Rx Coalescing interrupt */	
	mtdcri(SDR0, DCRN_SDR0_ICCRTX0, (mal->coales_param[0].tx_count & COAL_FRAME_MASK)<<SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX0, (mal->coales_param[0].rx_count & COAL_FRAME_MASK)<<SDR0_ICC_FTHR_SHIFT);
#else
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX0, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX0, CONFIG_IBM_EMAC_RX_COAL_TIMER);

	/* Enable the Tx/Rx Coalescing interrupt */	
	mtdcri(SDR0, DCRN_SDR0_ICCRTX0, TX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX0, RX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
#endif
#elif (defined(CONFIG_460EX) || defined(CONFIG_460GT)) && !defined(CONFIG_APM821xx)
	mtdcri(SDR0, DCRN_SDR0_ICCRTX0, SDR0_ICC_FLUSH);	/* Clear the counters */
	mtdcri(SDR0, DCRN_SDR0_ICCRTX1, SDR0_ICC_FLUSH);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX0, SDR0_ICC_FLUSH);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX1, SDR0_ICC_FLUSH);
#if defined(CONFIG_460GT)
	mtdcri(SDR0, DCRN_SDR0_ICCRTX2, SDR0_ICC_FLUSH);
	mtdcri(SDR0, DCRN_SDR0_ICCRTX3, SDR0_ICC_FLUSH);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX2, SDR0_ICC_FLUSH);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX3, SDR0_ICC_FLUSH);
#endif

	/* Set Tx/Rx Timer values */
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX0, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX1, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX0, CONFIG_IBM_EMAC_RX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX1, CONFIG_IBM_EMAC_RX_COAL_TIMER);

#if defined(CONFIG_460GT)
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX2, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX3, CONFIG_IBM_EMAC_TX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX2, CONFIG_IBM_EMAC_RX_COAL_TIMER);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX3, CONFIG_IBM_EMAC_RX_COAL_TIMER);
#endif

	/* Enable the Tx/Rx Coalescing interrupt */
	mtdcri(SDR0, DCRN_SDR0_ICCRTX0, TX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRTX1, TX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
#if defined(CONFIG_460GT)
	mtdcri(SDR0, DCRN_SDR0_ICCRTX2, TX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRTX3, TX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
#endif

	mtdcri(SDR0, DCRN_SDR0_ICCRRX0, RX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX1, RX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
#if defined(CONFIG_460GT)
	mtdcri(SDR0, DCRN_SDR0_ICCRRX2, RX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
	mtdcri(SDR0, DCRN_SDR0_ICCRRX3, RX_COAL_CNT << SDR0_ICC_FTHR_SHIFT);
#endif

#elif defined(CONFIG_460SX)
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX0, mal->coales_param[0].tx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX1, mal->coales_param[1].tx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX2, mal->coales_param[2].tx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRTX3, mal->coales_param[3].tx_time);

	mtdcri(SDR0, DCRN_SDR0_ICCTRRX0, mal->coales_param[0].rx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX1, mal->coales_param[1].rx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX2, mal->coales_param[2].rx_time);
	mtdcri(SDR0, DCRN_SDR0_ICCTRRX3, mal->coales_param[3].rx_time);

	set_ic_rxfthr(mal);
	set_ic_txfthr(mal);
#endif
	printk(KERN_INFO "MAL: Interrupt Coalescing TxCnt:%d RxCnt:%d TxTimer:%d RxTimer:%d\n",
		mal->coales_param[0].tx_count, mal->coales_param[0].rx_count,
		mal->coales_param[0].tx_time, mal->coales_param[0].rx_time);
}
#endif

static irqreturn_t mal_serr(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 esr = get_mal_dcrn(mal, MAL_ESR);

	set_mal_dcrn(mal, MAL_ESR, esr);		/* Clear the error status register */
	MAL_DBG(mal, "SERR %08x" NL, esr);

	if (esr & MAL_ESR_EVB) {
		/* Ignore Descriptor error, TXDE or RXDE interrupt will be generated anyway */
		if (esr & MAL_ESR_DE) return IRQ_HANDLED;
		/* PLB error, buggy hardware or incorrect physical address in BD (i.e. bug) */
		if (esr & MAL_ESR_PEIN) {
			if (net_ratelimit())
				printk(KERN_ERR "mal%d: system error, PLB (ESR = 0x%08x)\n", mal->index, esr);
			return IRQ_HANDLED;
		}

		/* OPB error, it's probably buggy hardware or incorrect EBC setup */
		if (net_ratelimit())
			printk(KERN_ERR "mal%d: system error, OPB (ESR = 0x%08x)\n", mal->index, esr);
	}
	return IRQ_HANDLED;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,19,0)
__always_inline bool local_napi_schedule_prep(struct napi_struct *n) {
	unsigned long val, new;
	do {
		val = READ_ONCE(n->state);
		if (unlikely(val & NAPIF_STATE_DISABLE)) return false;
		new = val | NAPIF_STATE_SCHED;
		new |= (val & NAPIF_STATE_SCHED) / NAPIF_STATE_SCHED * NAPIF_STATE_MISSED;
	} while (cmpxchg(&n->state, val, new) != val);
	return !(val & NAPIF_STATE_SCHED);
}
#else
#define local_napi_schedule_prep napi_schedule_prep
#endif

static __always_inline void mal_schedule_poll(struct mal_instance *mal) {
	if (likely(local_napi_schedule_prep(&mal->napi))) {
		MAL_DBG2(mal, "schedule_poll" NL);
		spin_lock(&mal->lock);
		mal_disable_eob_irq(mal);
		spin_unlock(&mal->lock);
		__napi_schedule_irqoff(&mal->napi); //__napi_schedule(&mal->napi);
	} else MAL_DBG2(mal, "already in poll" NL);
}

static irqreturn_t mal_txeob(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 r = get_mal_dcrn(mal, MAL_TXEOBISR);

	MAL_DBG2(mal, "txeob %08x" NL, r);
	mal_schedule_poll(mal);
	set_mal_dcrn(mal, MAL_TXEOBISR, r);

#ifdef CONFIG_PPC_DCR_NATIVE
	if (mal_has_feature(mal, MAL_FTR_CLEAR_ICINTSTAT))
		mtdcri(SDR0, DCRN_SDR_ICINTSTAT, (mfdcri(SDR0, DCRN_SDR_ICINTSTAT) | ICINTSTAT_ICTX));
#endif

	return IRQ_HANDLED;
}

static irqreturn_t mal_rxeob(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 r = get_mal_dcrn(mal, MAL_RXEOBISR);

	MAL_DBG2(mal, "rxeob %08x" NL, r);
	mal_schedule_poll(mal);
	set_mal_dcrn(mal, MAL_RXEOBISR, r);

#ifdef CONFIG_PPC_DCR_NATIVE
	if (mal_has_feature(mal, MAL_FTR_CLEAR_ICINTSTAT))
		mtdcri(SDR0, DCRN_SDR_ICINTSTAT, (mfdcri(SDR0, DCRN_SDR_ICINTSTAT) | ICINTSTAT_ICRX));
#endif

	return IRQ_HANDLED;
}

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
static irqreturn_t mal_coal_tx(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
    //mal->poll_tx = 1;
	mal_schedule_poll(mal);
	return IRQ_HANDLED;
}
static irqreturn_t mal_coal_rx(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
    //mal->poll_rx = 1;
	mal_schedule_poll(mal);
	return IRQ_HANDLED;
}
#endif

static irqreturn_t mal_txde(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 deir = get_mal_dcrn(mal, MAL_TXDEIR);
	
	set_mal_dcrn(mal, MAL_TXDEIR, deir);
	MAL_DBG(mal, "txde %08x" NL, deir);
	if (net_ratelimit())
		printk(KERN_ERR "mal%d: TX descriptor error (TXDEIR = 0x%08x)\n", mal->index, deir);
	return IRQ_HANDLED;
}

static irqreturn_t mal_rxde(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 deir = get_mal_dcrn(mal, MAL_RXDEIR);

#if defined (CONFIG_APM821xx) // APM821xx has just one single EMAC and one MAL channel
    {   struct mal_commac *mc = mal->commac;
#else
	list_for_each(l, &mal->list) {
		struct mal_commac *mc = list_entry(l, struct mal_commac, list);
#endif
		if (likely(deir & mc->rx_chan_mask)) {
			set_bit(MAL_COMMAC_RX_STOPPED, &mc->flags);
			mc->ops->rxde(mc->dev);
		}
	}
	MAL_DBG(mal, "rxde %08x" NL, deir);
	mal_schedule_poll(mal);
	set_mal_dcrn(mal, MAL_RXDEIR, deir);
	return IRQ_HANDLED;
}

static irqreturn_t mal_int(int irq, void *dev_instance) {
	struct mal_instance *mal = dev_instance;
	u32 esr = get_mal_dcrn(mal, MAL_ESR);

	if (esr & MAL_ESR_EVB) { // ESR contains at least one error
		if (esr & MAL_ESR_DE) {			/* descriptor error */
			if (esr & MAL_ESR_CIDT)	return mal_rxde(irq, dev_instance);
			else return mal_txde(irq, dev_instance);
		} else return mal_serr(irq, dev_instance);	/* SERR */
	}
	return IRQ_HANDLED;
}

void mal_poll_disable(struct mal_instance *mal, struct mal_commac *commac) {
	/* Spinlock-type semantics: only one caller disable poll at a time */
	while (test_and_set_bit(MAL_COMMAC_POLL_DISABLED, &commac->flags)) msleep(1);

	/* Synchronize with the MAL NAPI poller */
	napi_synchronize(&mal->napi);
}

void mal_poll_enable(struct mal_instance *mal, struct mal_commac *commac) {
	smp_wmb();
	clear_bit(MAL_COMMAC_POLL_DISABLED, &commac->flags);

	/* Feels better to trigger a poll here to catch up with events that
	 * may have happened on this channel while disabled. It will most
	 * probably be delayed until the next interrupt but that's mostly a
	 * non-issue in the context where this is called.
	 */
	napi_schedule(&mal->napi);
}

#if defined (CONFIG_APM821xx) // Moved from core.c

extern void emac_rx_enable(struct emac_instance *dev);

static void parse_rx_error(struct emac_instance *dev, u16 ctrl) {
	struct emac_error_stats *st = &dev->estats;

	DBG(dev, "BD RX error %04x" NL, ctrl);

	++st->rx_bd_errors;
	if (ctrl & EMAC_RX_ST_OE)	++st->rx_bd_overrun;
	if (ctrl & EMAC_RX_ST_BP)	++st->rx_bd_bad_packet;
	if (ctrl & EMAC_RX_ST_RP)	++st->rx_bd_runt_packet;
	if (ctrl & EMAC_RX_ST_SE)	++st->rx_bd_short_event;
	if (ctrl & EMAC_RX_ST_AE)	++st->rx_bd_alignment_error;
	if (ctrl & EMAC_RX_ST_BFCS)	++st->rx_bd_bad_fcs;
	if (ctrl & EMAC_RX_ST_PTL)	++st->rx_bd_packet_too_long;
	if (ctrl & EMAC_RX_ST_ORE)	++st->rx_bd_out_of_range;
	if (ctrl & EMAC_RX_ST_IRE)	++st->rx_bd_in_range;
}

static __always_inline void recycle_rx_skb(struct emac_instance *dev, int slot, int len, unsigned char* skbdata) {
	//struct sk_buff *skb = dev->rx_skb[slot];

	DBG2(dev, "recycle %d %d" NL, slot, len);
	if (likely(len))
		dma_map_single(&dev->ofdev->dev, skbdata - NET_IP_ALIGN, SKB_DATA_ALIGN(len + NET_IP_ALIGN), DMA_FROM_DEVICE);
	dev->rx_desc[slot].data_len = 0;
	wmb();
	dev->rx_desc[slot].ctrl = MAL_RX_CTRL_EMPTY| MAL_RX_CTRL_INTR| (slot == (NUM_RX_BUFF-1) ? MAL_RX_CTRL_WRAP : 0);
}

static __always_inline void rx_csum(struct emac_instance *dev, struct sk_buff *skb, u16 ctrl) {
#ifdef CONFIG_IBM_EMAC_TAH
	//if (!ctrl && dev->tah_dev) {
	if (likely(!ctrl)) {
		skb->ip_summed = CHECKSUM_UNNECESSARY;
		++dev->stats.rx_packets_csum;
	}
#endif
}

/* ECO: local version of skb_put for performance reasons */
#define skb_tail_pointer(skb) (skb)->tail
#define skb_putl(skb, len) SKB_LINEAR_ASSERT(skb); skb->tail += len; skb->len  += len;

// rx_sg_append was returning 0 and -1, used in ONLY in NOT comparisons --> invert return values 
static __always_inline int rx_sg_append(struct emac_instance *dev, int slot, int len, 
    unsigned char *data, struct sk_buff **skb_sg) {
    struct sk_buff *skb_sgp = *skb_sg;
	if (likely(skb_sgp != NULL)) {
		//int len = dev->rx_desc[slot].data_len;
		int tot_len = skb_sgp->len + len;

		if (unlikely(tot_len + NET_IP_ALIGN > dev->rx_skb_size)) {
			++dev->estats.rx_dropped_mtu;
			dev_kfree_skb(skb_sgp);
            skb_sg = NULL;
		} else {  //ECO
			//if(unlikely((dev->rx_sg_skb->tail + len) > dev->rx_sg_skb->end)) goto out;
			memcpy(skb_tail_pointer(skb_sgp), data, len);	// dev->rx_skb[slot]->data
			skb_putl(skb_sgp, len);
			recycle_rx_skb(dev, slot, len, data);	//dev->rx_skb[slot]->data
			return 1;
		}
	}
	recycle_rx_skb(dev, slot, 0, dev->rx_skb[slot]->data);
	return 0;
}

static __always_inline int __prepare_rx_skb(struct sk_buff *skb, struct emac_instance *dev, int slot,
        struct mal_descriptor *rx_desc) {

	dev->rx_skb[slot] = skb;
    rx_desc->data_len = 0;
    rx_desc->data_ptr =
	    dma_map_single(&dev->ofdev->dev, skb->data - NET_IP_ALIGN, dev->rx_sync_size, DMA_FROM_DEVICE) + NET_IP_ALIGN;
	wmb();
	rx_desc->ctrl = MAL_RX_CTRL_EMPTY | MAL_RX_CTRL_INTR | (slot == (NUM_RX_BUFF - 1) ? MAL_RX_CTRL_WRAP : 0);
	return 0;
}

inline int alloc_rx_skb(struct emac_instance *dev, int slot) {
	struct sk_buff *skb;
	skb = __netdev_alloc_skb_ip_align(dev->ndev, dev->rx_skb_size, GFP_KERNEL);
    if (unlikely(!skb))	return -ENOMEM;
	return __prepare_rx_skb(skb, dev, slot, &dev->rx_desc[slot]);
}
EXPORT_SYMBOL_GPL(alloc_rx_skb);

static inline int alloc_rx_skb_napi(struct emac_instance *dev, int slot) {
	struct sk_buff *skb;
	skb = napi_alloc_skb(&dev->mal->napi, dev->rx_skb_size);
    if (unlikely(!skb))	return -ENOMEM;
	return __prepare_rx_skb(skb, dev, slot, &dev->rx_desc[slot]);
}

/* NAPI poll context */
static int __always_inline poll_rx(void *param, int budget) {
	register struct emac_instance *dev = param;
	register int slot = dev->rx_slot, received = 0;
	register int len;
	register struct sk_buff *skb, **skb_sg;

	DBG2(dev, "poll_rx(%d)" NL, budget);

 again:
	while (budget > 0) {
		register u16 ctrl = dev->rx_desc[slot].ctrl;

		if (unlikely(ctrl & MAL_RX_CTRL_EMPTY)) break;

		skb = dev->rx_skb[slot];
		mb();
		len = dev->rx_desc[slot].data_len;

		if (unlikely(!MAL_IS_SINGLE_RX(ctrl))) goto sg;

		ctrl &= EMAC_BAD_RX_MASK;
		if (unlikely(ctrl && ctrl != EMAC_RX_TAH_BAD_CSUM)) {
			parse_rx_error(dev, ctrl);
			++dev->estats.rx_dropped_error;
			recycle_rx_skb(dev, slot, 0, skb->data);
			len = 0;
			goto next;
		}

		if (unlikely(len < ETH_HLEN)) {
			++dev->estats.rx_dropped_stack;
			recycle_rx_skb(dev, slot, len, skb->data);
			goto next;
		}

		if (len < EMAC_RX_COPY_THRESH) {
			struct sk_buff *copy_skb = napi_alloc_skb(&dev->mal->napi, len);
			if (unlikely(!copy_skb)) goto oom;

			memcpy(copy_skb->data - NET_IP_ALIGN, skb->data - NET_IP_ALIGN, len + NET_IP_ALIGN);  //is cacheable_memcpy
			recycle_rx_skb(dev, slot, len, skb->data);
			skb = copy_skb;
		} else if (unlikely(alloc_rx_skb_napi(dev, slot))) goto oom;

		skb_putl(skb, len); //ECO: local version of skb_put
	push_packet:
		skb->protocol = eth_type_trans(skb, dev->ndev);
		rx_csum(dev, skb, ctrl);

		if (unlikely(netif_receive_skb(skb) == NET_RX_DROP)) ++dev->estats.rx_dropped_stack;
	next:
		++dev->stats.rx_packets;
	skip:
		dev->stats.rx_bytes += len;
		slot = NXT_RX_SLOT(slot);
		--budget;
		++received;
		continue;
	sg:
        skb_sg = &dev->rx_sg_skb;
        // ECO TODO test if unlikely
		if (ctrl & MAL_RX_CTRL_FIRST) {
			//BUG_ON(dev->rx_sg_skb); // panic is not really helpful here
			if (unlikely(alloc_rx_skb_napi(dev, slot))) {
				DBG(dev, "rx OOM %d" NL, slot);
				++dev->estats.rx_dropped_oom;
				recycle_rx_skb(dev, slot, 0, skb->data);
                goto skip;
			} else {
				//dev->rx_sg_skb = skb;
                *skb_sg = skb;
				skb_putl(skb, len);
                goto skip;
			}
		} else if (rx_sg_append(dev, slot, len, skb->data, skb_sg) && (ctrl & MAL_RX_CTRL_LAST)) {
			//skb = dev->rx_sg_skb;
            //dev->rx_sg_skb = NULL;
            skb = *skb_sg;
            *skb_sg = NULL; 			

			ctrl &= EMAC_BAD_RX_MASK;
			if (unlikely(ctrl && ctrl != EMAC_RX_TAH_BAD_CSUM)) {
				parse_rx_error(dev, ctrl);
				++dev->estats.rx_dropped_error;
				dev_kfree_skb(skb);
				len = 0;
			} else goto push_packet;
		}
		goto skip;
	oom:
		DBG(dev, "rx OOM %d" NL, slot);
		/* Drop the packet and recycle skb */
		++dev->estats.rx_dropped_oom;
		recycle_rx_skb(dev, slot, 0, skb->data);
		goto next;
	}

	if (received) {
		DBG2(dev, "rx %d BDs" NL, received);
		dev->rx_slot = slot;
	}

	if (unlikely(budget && test_bit(MAL_COMMAC_RX_STOPPED, &dev->commac.flags))) {
		mb();
		if (!(dev->rx_desc[slot].ctrl & MAL_RX_CTRL_EMPTY)) {
			DBG2(dev, "rx restart" NL);
			received = 0;
			goto again;
		}

		if (dev->rx_sg_skb) {
			DBG2(dev, "dropping partial rx packet" NL);
			++dev->estats.rx_dropped_error;
			dev_kfree_skb(dev->rx_sg_skb);
			dev->rx_sg_skb = NULL;
		}

		clear_bit(MAL_COMMAC_RX_STOPPED, &dev->commac.flags);
		mal_enable_rx_channel(dev->mal, dev->mal_rx_chan);
		emac_rx_enable(dev);
		dev->rx_slot = 0;
	}
	return received;
}

/* Tx lock BHs */
static void parse_tx_error(struct emac_instance *dev, u16 ctrl) {
	struct emac_error_stats *st = &dev->estats;

	DBG(dev, "BD TX error %04x" NL, ctrl);

	++st->tx_bd_errors;
	if (ctrl & EMAC_TX_ST_BFCS)	++st->tx_bd_bad_fcs;
	if (ctrl & EMAC_TX_ST_LCS)	++st->tx_bd_carrier_loss;
	if (ctrl & EMAC_TX_ST_ED)	++st->tx_bd_excessive_deferral;
	if (ctrl & EMAC_TX_ST_EC)	++st->tx_bd_excessive_collisions;
	if (ctrl & EMAC_TX_ST_LC)	++st->tx_bd_late_collision;
	if (ctrl & EMAC_TX_ST_MC)	++st->tx_bd_multple_collisions;
	if (ctrl & EMAC_TX_ST_SC)	++st->tx_bd_single_collision;
	if (ctrl & EMAC_TX_ST_UR)	++st->tx_bd_underrun;
	if (ctrl & EMAC_TX_ST_SQE)	++st->tx_bd_sqe;
}

#define netif_queue_stopped(ndev) test_bit(__QUEUE_STATE_DRV_XOFF, &ndev->_tx[0].state)
static __always_inline void poll_tx(struct emac_instance *dev) {
	DBG2(dev, "poll_tx, %d %d" NL, dev->tx_cnt, dev->ack_slot);

    netif_tx_lock_bh(dev->ndev);
	if (likely(dev->tx_cnt)) {	// We have something to transmit
    	register u16 ctrl;
		register int slot = dev->ack_slot, n = 0;
		//register int slot = ack_slot, n = 0;
        register struct sk_buff *skb;
	again:  /* Release slots and skb's for packets transmited */
		ctrl = dev->tx_desc[slot].ctrl;
 		if (likely(!(ctrl & MAL_TX_CTRL_READY))) {
			skb = dev->tx_skb[slot];
			++n;

			if (likely(skb)) {
				dev_kfree_skb(skb);
				dev->tx_skb[slot] = NULL;
			}
			slot = NXT_TX_SLOT(slot);
			if (unlikely(ctrl & EMAC_IS_BAD_TX)) parse_tx_error(dev, ctrl);
			if (--dev->tx_cnt) goto again;
		} 

		if (likely(n)) {
			dev->ack_slot = slot;
			//ack_slot = slot;
 			if (unlikely(netif_queue_stopped(dev->ndev) && dev->tx_cnt < EMAC_TX_WAKEUP_THRESH))
				netif_wake_queue(dev->ndev);
			DBG2(dev, "tx %d pkts" NL, n);
		}
 	}
#ifdef CONFIG_IBM_EMAC_MASK_CEXT
	else {
		DBG(dev, "Testing for idle... " NL);
		if (atomic_read(&dev->mask_cext_enable)) {
			if (!atomic_read(&dev->idle_mode)) {
			      DBG(dev, "Entering idle mode" NL);
			      emac_start_idlemode(dev);
			      atomic_set(&dev->idle_mode, 1);
			} else DBG(dev, "Already In Idle Mode" NL);
		}
	}
#endif
	netif_tx_unlock_bh(dev->ndev);
}

/* NAPI poll context */
static __always_inline int peek_rx_sg(struct emac_instance *dev) {
	register int slot = dev->rx_slot;  // start will last used slot
    register u16 *rx_desc_ctrl = (u16 *)&dev->rx_desc[slot];
	while (1) {
        if (*rx_desc_ctrl & MAL_RX_CTRL_EMPTY) return 0;
		else if (unlikely(*rx_desc_ctrl & MAL_RX_CTRL_LAST)) return 1;
		slot = NXT_RX_SLOT(slot);
        rx_desc_ctrl += sizeof(struct mal_descriptor);
        if (unlikely(slot == 0)) rx_desc_ctrl = (u16 *) &dev->rx_desc[0]; //wrap around
	}
}

#endif

static int mal_poll(struct napi_struct *napi, int budget) {
	struct mal_instance *mal = container_of(napi, struct mal_instance, napi);
	register int received = 0;
	unsigned long flags;
#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    #define continue_if(x)
    register struct mal_commac *mc = mal->poll_commac;
    register struct emac_instance *dev = mc->dev;
#else
    #define continue_if(x) if (x) continue
	struct list_head *l;
#endif
	MAL_DBG2(mal, "poll(%d)" NL, budget);

	/* Process TX skbs */
#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
	//if (mal->poll_tx) {
    {
#else
	list_for_each(l, &mal->poll_list) {
		struct mal_commac *mc =	list_entry(l, struct mal_commac, poll_list);
        struct emac_instance *dev = mc->dev;
#endif
		//mc->ops->poll_tx(dev); // Poll if we have something to transmit
		poll_tx(dev);
        //mal->poll_tx = 0;
 	}


	/* Process RX skbs */
#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    //if (!mal->poll_rx) return 0;
	if (likely(mc && !test_bit(MAL_COMMAC_POLL_DISABLED, &mc->flags))) {
#else
	 // We _might_ need something more smart here to enforce polling fairness. 
    list_for_each(l, &mal->poll_list) {
		struct mal_commac *mc =	list_entry(l, struct mal_commac, poll_list);
        struct emac_instance *dev = mc->dev;
#endif

		register int n;
        continue_if(unlikely(test_bit(MAL_COMMAC_POLL_DISABLED, &mc->flags)));
		//n = mc->ops->poll_rx(dev, budget - received);
		n = poll_rx(dev, budget - received);
		if (n) {
			received += n;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,19,0)
			budget -= n;
			if (budget <= 0) return received;  //goto more_work; // XXX What if this is the last one ?
#else
			if (received >= budget) return budget;
#endif
		}
	}

	/* We need to disable IRQs to protect from RXDE IRQ here */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,19,0)
	spin_lock_irqsave(&mal->lock, flags);
	__napi_complete(napi);
	mal_enable_eob_irq(mal);
	spin_unlock_irqrestore(&mal->lock, flags);
#else
	if (napi_complete_done(napi, received)) {
		spin_lock_irqsave(&mal->lock, flags);
		mal_enable_eob_irq(mal);
		spin_unlock_irqrestore(&mal->lock, flags);
	}
#endif
	/* Check for "rotting" packet(s) */
#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
	if (likely(mc && !test_bit(MAL_COMMAC_POLL_DISABLED, &mc->flags))) {
#else
	list_for_each(l, &mal->poll_list) {
		struct mal_commac *mc =	list_entry(l, struct mal_commac, poll_list);
        struct emac_instance *dev = mc->dev;
#endif
        continue_if(unlikely(test_bit(MAL_COMMAC_POLL_DISABLED, &mc->flags)));

		//if (unlikely(mc->ops->peek_rx(dev) || test_bit(MAL_COMMAC_RX_STOPPED, &mc->flags))) {
		if (unlikely(peek_rx_sg(dev) || test_bit(MAL_COMMAC_RX_STOPPED, &mc->flags))) {
			MAL_DBG2(mal, "rotting packet" NL);
			if (!napi_reschedule(napi))	return received; //	goto more_work;

			spin_lock_irqsave(&mal->lock, flags);
			mal_disable_eob_irq(mal);
			spin_unlock_irqrestore(&mal->lock, flags);
		}
		//mc->ops->poll_tx(dev);
		poll_tx(dev);
	}

// more_work:
	MAL_DBG2(mal, "poll() %d <- %d" NL, budget, received);
	return received;
}

static void mal_reset(struct mal_instance *mal) {
	int n = 10;

	MAL_DBG(mal, "reset" NL);
	set_mal_dcrn(mal, MAL_CFG, MAL_CFG_SR);
    mal->mal_cfg = MAL_CFG_SR;

	/* Wait for reset to complete (1 system clock) */
	while ((get_mal_dcrn(mal, MAL_CFG) & MAL_CFG_SR) && n)
		--n;

	if (unlikely(!n))
		printk(KERN_ERR "mal%d: reset timeout\n", mal->index);
}

int mal_get_regs_len(struct mal_instance *mal) {
	return sizeof(struct emac_ethtool_regs_subhdr) + sizeof(struct mal_regs);
}

void *mal_dump_regs(struct mal_instance *mal, void *buf)
{
	struct emac_ethtool_regs_subhdr *hdr = buf;
	struct mal_regs *regs = (struct mal_regs *)(hdr + 1);
	int i;

	hdr->version = mal->version;
	hdr->index = mal->index;

	regs->tx_count = mal->num_tx_chans;
	regs->rx_count = mal->num_rx_chans;

	regs->cfg = get_mal_dcrn(mal, MAL_CFG);
	regs->esr = get_mal_dcrn(mal, MAL_ESR);
	regs->ier = get_mal_dcrn(mal, MAL_IER);
	regs->tx_casr = get_mal_dcrn(mal, MAL_TXCASR);
	regs->tx_carr = get_mal_dcrn(mal, MAL_TXCARR);
	regs->tx_eobisr = get_mal_dcrn(mal, MAL_TXEOBISR);
	regs->tx_deir = get_mal_dcrn(mal, MAL_TXDEIR);
	regs->rx_casr = get_mal_dcrn(mal, MAL_RXCASR);
	regs->rx_carr = get_mal_dcrn(mal, MAL_RXCARR);
	regs->rx_eobisr = get_mal_dcrn(mal, MAL_RXEOBISR);
	regs->rx_deir = get_mal_dcrn(mal, MAL_RXDEIR);

	for (i = 0; i < regs->tx_count; ++i)
		regs->tx_ctpr[i] = get_mal_dcrn(mal, MAL_TXCTPR(i));

	for (i = 0; i < regs->rx_count; ++i) {
		regs->rx_ctpr[i] = get_mal_dcrn(mal, MAL_RXCTPR(i));
		regs->rcbs[i] = get_mal_dcrn(mal, MAL_RCBS(i));
	}
	return regs + 1;
}

static int mal_probe(struct platform_device *ofdev) {
	struct mal_instance *mal;
	int err = 0, i, bd_size, index = mal_count++;
	unsigned int dcr_base;
	const u32 *prop;
	const char *str_prop;
	u32 cfg;
	unsigned long irqflags;
	irq_handler_t hdlr_serr, hdlr_txde, hdlr_rxde;
	struct device *dp = &ofdev->dev;
	struct device_node *np = dp->of_node;

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	int num_phys_chans, coal_intr_index;
#endif

	str_prop = of_get_property(np, "descriptor-memory", NULL);
	if (str_prop && (!strcmp(str_prop,"ocm") || !strcmp(str_prop,"OCM"))) {
		phys_addr_t	bd_phys;
		printk(KERN_INFO "MAL: Allocating MAL instance on OCM\n");
		mal = ppc4xx_ocm_alloc(&bd_phys, sizeof(struct mal_instance), 4, PPC4XX_OCM_NON_CACHED, "mal_instance");
		memset(mal, 0, sizeof(struct mal_instance));
		mal->desc_memory = MAL_DESC_MEM_OCM;
	} else mal = kzalloc(sizeof(struct mal_instance), GFP_KERNEL);
	if (!mal)
		return -ENOMEM;

	mal->index = index;
	mal->ofdev = ofdev;
	mal->version = of_device_is_compatible(np, "ibm,mcmal2") ? 2 : 1;

	MAL_DBG(mal, "probe" NL);

	prop = of_get_property(np, "num-tx-chans", NULL);
	if (prop == NULL) {
		printk(KERN_ERR "mal%d: can't find MAL num-tx-chans property!\n", index);
		err = -ENODEV;
		goto fail;
	}
	mal->num_tx_chans = prop[0];

	prop = of_get_property(np, "num-rx-chans", NULL);
	if (prop == NULL) {
		printk(KERN_ERR "mal%d: can't find MAL num-rx-chans property!\n", index);
		err = -ENODEV;
		goto fail;
	}
	mal->num_rx_chans = prop[0];

	dcr_base = dcr_resource_start(np, 0);
	if (dcr_base == 0) {
		printk(KERN_ERR "mal%d: can't find DCR resource!\n", index);
		err = -ENODEV;
		goto fail;
	}
	mal->dcr_host = dcr_map(np, dcr_base, 0x100);
	if (!DCR_MAP_OK(mal->dcr_host)) {
		printk(KERN_ERR "mal%d: failed to map DCRs !\n", index);
		err = -ENODEV;
		goto fail;
	}

	if (of_device_is_compatible(np, "ibm,mcmal-405ez")) {
#if defined(CONFIG_IBM_EMAC_MAL_CLR_ICINTSTAT) && defined(CONFIG_IBM_EMAC_MAL_COMMON_ERR)
		mal->features |= (MAL_FTR_CLEAR_ICINTSTAT | MAL_FTR_COMMON_ERR_INT);
#else
		printk(KERN_ERR "%pOF: Support for 405EZ not enabled!\n", np);
		err = -ENODEV;
		goto fail;
#endif
	}

	mal->txeob_irq = irq_of_parse_and_map(np, 0);
	mal->rxeob_irq = irq_of_parse_and_map(np, 1);
	mal->serr_irq  = irq_of_parse_and_map(np, 2);

	if (mal_has_feature(mal, MAL_FTR_COMMON_ERR_INT))
		mal->txde_irq = mal->rxde_irq = mal->serr_irq;
	else {
		mal->txde_irq = irq_of_parse_and_map(np, 3);
		mal->rxde_irq = irq_of_parse_and_map(np, 4);
	}

	if (!mal->txeob_irq|| !mal->rxeob_irq|| !mal->serr_irq|| !mal->txde_irq|| !mal->rxde_irq) {
		printk(KERN_ERR "mal%d: failed to map interrupts !\n", index);
		err = -ENODEV;
		goto fail_unmap;
	}

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	/* Number of Tx channels is equal to Physical channels */
	/* Rx channels include Virtual channels so use Tx channels */
	BUG_ON(mal->num_tx_chans > MAL_MAX_PHYS_CHANNELS);
	num_phys_chans = mal->num_tx_chans;
	/* Older revs in 460EX and 460GT have coalesce bug in h/w */
#if (defined(CONFIG_460EX) || defined(CONFIG_460GT)) && !defined(CONFIG_APM821xx)
	{	unsigned int pvr = mfspr(SPRN_PVR);
		unsigned short min = PVR_MIN(pvr);
		if (min < 4) {
			printk(KERN_INFO "PVR %x Intr Coal disabled: H/W bug\n", pvr);
			mal->coalesce_disabled = 1;
		}
	}
#else
	mal->coalesce_disabled = 0;
#endif
	coal_intr_index = 5;
	/* If device tree doesn't Interrupt coal IRQ, fall back to EOB IRQ */
	for (i = 0; (i < num_phys_chans) && (mal->coalesce_disabled == 0) ; i++) {
		mal->txcoal_irq[i] = irq_of_parse_and_map(np, coal_intr_index++);
		if (mal->txcoal_irq[i] == NO_IRQ) {
			printk(KERN_INFO "MAL: No device tree IRQ for TxCoal%d  - disabling coalescing\n", i);
			mal->coalesce_disabled = 1;
		}
	}
	for (i = 0; (i < num_phys_chans) && (mal->coalesce_disabled == 0); i++) {
		mal->rxcoal_irq[i] = irq_of_parse_and_map(np, coal_intr_index++);
		if (mal->rxcoal_irq[i] == NO_IRQ) {
			printk(KERN_INFO "MAL: No device tree IRQ for RxCoal%d  - disabling coalescing\n", i);
			mal->coalesce_disabled = 1;
		}
	}
#endif

#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    mal->commac = NULL;
#else
	INIT_LIST_HEAD(&mal->poll_list);
	INIT_LIST_HEAD(&mal->list);
#endif
	spin_lock_init(&mal->lock);

	init_dummy_netdev(&mal->dummy_dev);

	netif_napi_add(&mal->dummy_dev, &mal->napi, mal_poll, CONFIG_IBM_EMAC_POLL_WEIGHT);

	/* Load power-on reset defaults */
	mal_reset(mal);

	/* Set the MAL configuration register */
	cfg = (mal->version == 2) ? MAL2_CFG_DEFAULT : MAL1_CFG_DEFAULT;
	cfg |= MAL_CFG_PLBB | MAL_CFG_OPBBL | MAL_CFG_LEA;

	/* Current Axon is not happy with priority being non-0, it can deadlock, fix it up here */
	if (of_device_is_compatible(np, "ibm,mcmal-axon"))
		cfg &= ~(MAL2_CFG_RPP_10 | MAL2_CFG_WPP_10);

	/* Apply configuration */
	set_mal_dcrn(mal, MAL_CFG, cfg);
    mal->mal_cfg = cfg; // Cache mal configuration

	/* Allocate space for BD rings */
	BUG_ON(mal->num_tx_chans <= 0 || mal->num_tx_chans > 32);
	BUG_ON(mal->num_rx_chans <= 0 || mal->num_rx_chans > 32);

	bd_size = sizeof(struct mal_descriptor) * 
		(NUM_TX_BUFF * mal->num_tx_chans + NUM_RX_BUFF * mal->num_rx_chans);
	
	if (mal->desc_memory == MAL_DESC_MEM_OCM) {
		mal->bd_virt = ppc4xx_ocm_alloc(&mal->bd_phys, bd_size, 4, PPC4XX_OCM_NON_CACHED, "mal_descriptors");
		mal->bd_dma  = (u32)mal->bd_phys;
	}

	if (mal->bd_virt == NULL) {
		// Allocate BD on SDRAM in case !MAL_DESC_MEM_OCM or failed OCM alloc
		if (mal->desc_memory == MAL_DESC_MEM_OCM){
			printk(KERN_INFO "mal%d: failed OCM alloc, descriptor-memory = SDRAM\n", index);
			mal->desc_memory = MAL_DESC_MEM_SDRAM;
		}
		mal->bd_virt = dma_alloc_coherent(dp, bd_size, &mal->bd_dma, GFP_KERNEL |__GFP_ZERO);
	}

	if (mal->bd_virt == NULL) {
		printk(KERN_ERR "mal%d: out of memory allocating RX/TX descriptors!\n", index);
		err = -ENOMEM;
		goto fail_unmap;
	}

	//memset(mal->bd_virt, 0, bd_size);
	for (i = 0; i < mal->num_tx_chans; ++i) {
		if (mal->desc_memory == MAL_DESC_MEM_OCM)
			set_mal_dcrn(mal, MAL_TXBADDR, (mal->bd_phys >> 32));
		set_mal_dcrn(mal, MAL_TXCTPR(i), mal->bd_dma + sizeof(struct mal_descriptor) *
			     mal_tx_bd_offset(mal, i));
	}

	for (i = 0; i < mal->num_rx_chans; ++i) {
		if (mal->desc_memory == MAL_DESC_MEM_OCM)
			set_mal_dcrn(mal, MAL_RXBADDR, (u32)(mal->bd_phys >> 32));
		set_mal_dcrn(mal, MAL_RXCTPR(i), mal->bd_dma + sizeof(struct mal_descriptor) *
			     mal_rx_bd_offset(mal, i));
	}

	if (mal_has_feature(mal, MAL_FTR_COMMON_ERR_INT)) {
		irqflags = IRQF_SHARED;
		hdlr_serr = hdlr_txde = hdlr_rxde = mal_int;
	} else {
		irqflags = 0;
		hdlr_serr = mal_serr;
		hdlr_txde = mal_txde;
		hdlr_rxde = mal_rxde;
	}

	err = request_irq(mal->serr_irq, hdlr_serr, irqflags, "MAL SERR", mal);
	if (err) goto fail2;
	err = request_irq(mal->txde_irq, hdlr_txde, irqflags, "MAL TX DE", mal);
	if (err) goto fail3;

	err = request_irq(mal->rxde_irq, hdlr_rxde, irqflags, "MAL RX DE", mal);
	if (err) goto fail4;

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	for (i = 0; (i < num_phys_chans) && (!mal->coalesce_disabled); i++) {
		err = request_irq(mal->txcoal_irq[i], mal_coal_tx, 0, tx_coal_irqname[i], mal);
		if (err) {
			printk(KERN_INFO "MAL: TxCoal%d ReqIRQ failed - disabling coalescing\n", i);
			mal->txcoal_irq[i] = NO_IRQ;
			mal->coalesce_disabled = 1;
			break;
		}
	}
	for (i = 0; (i < num_phys_chans) && (!mal->coalesce_disabled); i++) {
		err = request_irq(mal->rxcoal_irq[i], mal_coal_rx, 0, rx_coal_irqname[i], mal);
		if (err) {
			printk(KERN_INFO "MAL: RxCoal%d ReqIRQ failed - disabling coalescing\n", i);
			mal->rxcoal_irq[i] = NO_IRQ;
			mal->coalesce_disabled = 1;
			break;
		}
	}

	if (mal->coalesce_disabled) {	/* Fall back to EOB IRQ if coalesce not supported */
		for (i = 0; i < num_phys_chans; i++) { 	// Clean up any IRQs allocated for Coalescing
			if (mal->txcoal_irq[i] != NO_IRQ) free_irq(mal->txcoal_irq[i], mal);
			if (mal->rxcoal_irq[i] != NO_IRQ) free_irq(mal->rxcoal_irq[i], mal);
		}
#endif

	err = request_irq(mal->txeob_irq, mal_txeob, 0, "MAL TX EOB", mal);
	if (err) goto fail5;
	err = request_irq(mal->rxeob_irq, mal_rxeob, 0, "MAL RX EOB", mal);
	if (err) {
		mal->rxeob_irq = NO_IRQ;
		goto fail6;
	}
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	}
#endif

	/* Enable all MAL SERR interrupt sources */
	set_mal_dcrn(mal, MAL_IER, MAL_IER_EVENTS);

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	if (!mal->coalesce_disabled) {
		for (i = 0; i < 4; i++) {
			mal->coales_param[i].tx_count = CONFIG_IBM_EMAC_TX_COAL_COUNT & COAL_FRAME_MASK;
			mal->coales_param[i].rx_count = CONFIG_IBM_EMAC_RX_COAL_COUNT & COAL_FRAME_MASK;
			mal->coales_param[i].tx_time  = CONFIG_IBM_EMAC_TX_COAL_TIMER;
			mal->coales_param[i].rx_time  = CONFIG_IBM_EMAC_RX_COAL_TIMER;
		}
		mal_enable_coal(mal);
	}
#endif

	/* Enable EOB interrupt */
	mal_enable_eob_irq(mal);

	printk(KERN_INFO "MAL v%d %pOF, %d TX channels, %d RX channels\n", mal->version, np,
	       mal->num_tx_chans, mal->num_rx_chans);

	/* Advertise this instance to the rest of the world */
	wmb();
	platform_set_drvdata(ofdev, mal);

	return 0;

 fail6:
	free_irq(mal->txeob_irq, mal);
 fail5:
	free_irq(mal->rxde_irq, mal);
 fail4:
	free_irq(mal->txde_irq, mal);
 fail3:
	free_irq(mal->serr_irq, mal);
 fail2:
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	if (!mal->coalesce_disabled) {
		for (i = 0; i < num_phys_chans; i++) {
			if (mal->txcoal_irq[i] != NO_IRQ) free_irq(mal->txcoal_irq[i], mal);
			if (mal->rxcoal_irq[i] != NO_IRQ) free_irq(mal->rxcoal_irq[i], mal);
		}
	}
#endif
	if (mal->desc_memory == MAL_DESC_MEM_OCM) ppc4xx_ocm_free(mal->bd_virt);
	else dma_free_coherent(dp, bd_size, mal->bd_virt, mal->bd_dma);
 fail_unmap:
	dcr_unmap(mal->dcr_host, 0x100);
 fail:
	kfree(mal);
	return err;
}

static int mal_remove(struct platform_device *ofdev) {
	struct mal_instance *mal = platform_get_drvdata(ofdev);
#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	int i, num_phys_chans;
#endif

	MAL_DBG(mal, "remove" NL);

	/* Synchronize with scheduled polling */
	napi_disable(&mal->napi);

#if defined (CONFIG_APM821xx) // APM821xx has just a single EMAC/MAL RX/TX channel
    if (mal->commac) 
#else
	if (!list_empty(&mal->list)) /* Removing mal with active commac : *very* bad */
#endif
		WARN(1, KERN_EMERG "mal%d: commac list is not empty on remove!\n", mal->index);
	free_irq(mal->serr_irq, mal);
	free_irq(mal->txde_irq, mal);
	free_irq(mal->txeob_irq, mal);
	free_irq(mal->rxde_irq, mal);
	free_irq(mal->rxeob_irq, mal);

#ifdef CONFIG_IBM_EMAC_INTR_COALESCE
	num_phys_chans = mal->num_tx_chans;
	if (!mal->coalesce_disabled) {
		for (i = 0; i < num_phys_chans; i++) {
			if (mal->txcoal_irq[i]) free_irq(mal->txcoal_irq[i], mal);
			if (mal->rxcoal_irq[i]) free_irq(mal->rxcoal_irq[i], mal);
		}
	}
#endif
	mal_reset(mal);

	if (mal->desc_memory == MAL_DESC_MEM_OCM) ppc4xx_ocm_free(mal->bd_virt);
	else dma_free_coherent(&ofdev->dev, sizeof(struct mal_descriptor) *
		(NUM_TX_BUFF * mal->num_tx_chans + NUM_RX_BUFF * mal->num_rx_chans), mal->bd_virt, mal->bd_dma);
	kfree(mal);
	return 0;
}

static const struct of_device_id mal_platform_match[] = {
	{	.compatible	= "ibm,mcmal",	},
	{	.compatible	= "ibm,mcmal2",	},
	{	.type		= "mcmal-dma",			/* Backward compat */
		.compatible	= "ibm,mcmal",	},
	{	.type		= "mcmal-dma",
		.compatible	= "ibm,mcmal2",	},
	{},
};

static struct platform_driver mal_of_driver = {
	.driver = {
		.name = "mcmal",
		.of_match_table = mal_platform_match,
	},
	.probe = mal_probe,
	.remove = mal_remove,
};

int __init mal_init(void) {
	return platform_driver_register(&mal_of_driver);
}

void mal_exit(void) {
	platform_driver_unregister(&mal_of_driver);
}
