#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/of_platform.h>
#include <linux/libata.h>
#include <linux/rtc.h>

#include "../leds/leds.h"

#include <scsi/scsi_host.h>
#include <scsi/scsi_cmnd.h>

#ifdef CONFIG_SATA_DWC_DEBUG
#define DWC_DEBUG
#define dwc_dev_dbg(dev, format, arg...) dev_printk(KERN_INFO, dev, format, ##arg)
#define dwc_port_dbg(ap, format, arg...) ata_port_printk(ap, KERN_INFO, format, ##arg)
#define dwc_link_dbg(link, format, arg...) ata_link_printk(link, KERN_INFO, format, ##arg)
#else
#define dwc_dev_dbg(dev, format, arg...)
#define dwc_port_dbg(ap, format, arg...)
#define dwc_link_dbg(link, format, arg...)
#endif

#ifdef CONFIG_SATA_DWC_VDEBUG
#define DEBUG_NCQ
#define dwc_dev_vdbg(dev, format, arg...) dev_printk(KERN_INFO, dev, format, ##arg)
#define dwc_port_vdbg(ap, format, arg...) ata_port_printk(ap, KERN_INFO, format, ##arg)
#define dwc_link_vdbg(link, format, arg...) ata_link_printk(link, KERN_INFO, format, ##arg)
#define dwc_printk_vdbg(format, arg...) printk(KERN_INFO format, ##arg)
#define print_dma_registers_vdbg(x) 	print_dma_registers(x)
#define print_dma_config_vdbg(x,y,z) 	print_dma_config(x,y,z)
static const char* sata_reg2txt(unsigned int id);
#else
#define dwc_dev_vdbg(dev, format, arg...)
#define dwc_port_vdbg(ap, format, arg...)
#define dwc_link_vdbg(link, format, arg...)
#define dwc_printk_vdbg(format, arg...)
#define print_dma_registers_vdbg(x)
#define print_dma_config_vdbg(x,y,z)
#endif

#define dwc_dev_info(dev, format, arg...) dev_printk(KERN_INFO, dev, format, ##arg)
#define dwc_port_info(ap, format, arg...) ata_port_printk(ap, KERN_INFO, format, ##arg)
#define dwc_link_info(link, format, arg...) ata_link_printk(link, KERN_INFO, format, ##arg)
#define dwc_printk(format, arg...) printk(KERN_INFO format, ##arg)

#define DRV_NAME        "sata-dwc"
#define DRV_VERSION     "2.1"

/* Port Multiplier discovery Signature */
#define PSCR_SCONTROL_DET_ENABLE	0x00000001
#define PSCR_SSTATUS_DET_PRESENT	0x00000001
#define PSCR_CLEAR_INTPR_DIAG_X		0x04000000

/* Port multiplier port entry in SCONTROL register */
#define SCONTROL_PMP_MASK		0x000f0000
#define PMP_TO_SCONTROL(p)		((p << 16) & 0x000f0000)
#define SCONTROL_TO_PMP(p)		(((p) & 0x000f0000) >> 16)


/* SATA DMA driver Globals */
#if defined(CONFIG_APM821xx)
#define DMA_NUM_CHANS			2	// Contrary to the documentation APM821xx has 2 DMA channels
#else
#define DMA_NUM_CHANS			1
#endif
#define DMA_NUM_CHAN_REGS		8	// 8 * 58x = 2C0 (but only 3 channels exist)
#define DMA_ALL_CHAN_MASK		(1 << DMA_NUM_CHANS) - 1

/* SATA DMA Register definitions */
#if defined(CONFIG_APM821xx)
#define AHB_DMA_BRST_DFLT       64  /* 16 data items burst length */
#define BURST_LENGTH_ENCODE		3   /* no need to compute if fixed anyhow */	
//#define AHB_DMA_BRST_DFLT       128  /* 32 data items burst length */
//#define BURST_LENGTH_ENCODE		4   /* no need to compute if fixed anyhow */
#define DMA_BLOCK_SIZE			0x2000	/* 8192 = 8K */	
//#define DMA_BLOCK_SIZE			0x8000  /* 64K */	
#else
#define AHB_DMA_BRST_DFLT		64	/* 16 data items burst length */
#define BURST_LENGTH_ENCODE		3   /* no need to compute if fixed anyhow */	
#endif

#if defined(CONFIG_APOLLO3G) // && defined(DWC_DEBUG)
extern void signal_hdd_led(int, int);
#endif

struct dmareg {
	u32 low;		/* Low bits 0-31 */
	u32 high;		/* High bits 32-63 */
};

/* DMA Per Channel registers */
struct dmaChanRegs {
	struct dmareg sar;		/* Source Address */
	struct dmareg dar;		/* Destination address */
	struct dmareg llp;		/* Linked List Pointer */
	struct dmareg ctl;		/* Control */
	struct dmareg sstat;	/* Source Status not implemented in core */
	struct dmareg dstat;	/* Destination Status not implemented in core */
	struct dmareg sstatar;	/* Source Status Address not impl in core */
	struct dmareg dstatar;	/* Destination Status Address not implemented */
	struct dmareg cfg;		/* Config */
	struct dmareg sgr;		/* Source Gather */
	struct dmareg dsr;		/* Destination Scatter */
};

/* Generic Interrupt Registers */
struct dmaIntrRegs {
	struct dmareg tfr;		/* Transfer Interrupt */
	struct dmareg block;	/* Block Interrupt */
	struct dmareg srctran;	/* Source Transfer Interrupt */
	struct dmareg dsttran;	/* Dest Transfer Interrupt */
	struct dmareg error;	/* Error */
};

struct ahb_dma_regs {
	struct dmaChanRegs	chan_regs[DMA_NUM_CHAN_REGS];
	struct dmaIntrRegs	interrupt_raw;	/* Raw Interrupt */
	struct dmaIntrRegs	interrupt_status;	/* Interrupt Status */
	struct dmaIntrRegs	interrupt_mask;	/* Interrupt Mask */
	struct dmaIntrRegs	interrupt_clear;	/* Interrupt Clear */
	struct dmareg		statusInt;		/* Interrupt combined */
	struct dmareg		rq_srcreg;		/* Src Trans Req */
	struct dmareg		rq_dstreg;		/* Dst Trans Req */
	struct dmareg		rq_sgl_srcreg;	/* Sngl Src Trans Req */
	struct dmareg		rq_sgl_dstreg;	/* Sngl Dst Trans Req */
	struct dmareg		rq_lst_srcreg;	/* Last Src Trans Req */
	struct dmareg		rq_lst_dstreg;	/* Last Dst Trans Req */
	struct dmareg		dma_cfg;		/* DMA Config, overall SATA DMA enablement */
	struct dmareg		dma_chan_en;	/* DMA Channel Enable */
	struct dmareg		dma_id;			/* DMA ID */
	struct dmareg		dma_test;		/* DMA Test */
	struct dmareg		res1;			/* reserved */
	struct dmareg		res2;			/* reserved */

	/* DMA Comp Params
	 * Param 6 = dma_param[0], Param 5 = dma_param[1],
	 * Param 4 = dma_param[2] ...
	 */
	struct dmareg		dma_params[6];
};
/* Globals */
static struct ahb_dma_regs *sata_dma_regs = 0;

/* Data structure for linked list item */
struct lli {
	u32		sar;			/* Source Address */
	u32		dar;			/* Destination address */
	u32		llp;			/* Linked List Pointer */
	struct  dmareg ctl;		/* Control */
#if defined(CONFIG_APM821xx)
	u32		dstat;  		/* Source status is not supported */
#else
	struct	dmareg dstat;	/* Destination Status */
#endif
};

#define SATA_DWC_DMAC_LLI_SZ		(sizeof(struct lli))
#define SATA_DWC_DMAC_LLI_NUM		64
#define SATA_DWC_DMAC_TWIDTH_BYTES	4
#define SATA_DWC_DMAC_LLI_TBL_SZ	(SATA_DWC_DMAC_LLI_SZ * SATA_DWC_DMAC_LLI_NUM)
#define SATA_DWC_DMAC_CTRL_TSIZE_MAX (0x00000800 * SATA_DWC_DMAC_TWIDTH_BYTES) //8K
/* DMA Register Operation Bits */
/* Bitfields in CFG */
#define DW_CFG_DMA_EN		(1 << 0)		// Enable AHB DMA 
#define DMA_CHANNEL(ch)		(0x00000001 << (ch))	/* Select channel */
#define DMA_ENABLE_CHAN(ch)	((0x00000001 << (ch)) |	((0x000000001 << (ch)) << 8))
#define DMA_DISABLE_CHAN(ch)	(0x00000000 | ((0x000000001 << (ch)) << 8))

/* Channel Control Register */
#define DMA_CTL_BLK_TS(size)	((size) & 0x000000FFF)	/* Blk Transfer size */
#define DMA_CTL_LLP_SRCEN	0x10000000	/* Blk chain enable Src */
#define DMA_CTL_LLP_DSTEN	0x08000000	/* Blk chain enable Dst */
/*
 * This define is used to set block chaining disabled in the control low
 * register.  It is already in little endian format so it can be &'d dirctly.
 * It is essentially: cpu_to_le32(~(DMA_CTL_LLP_SRCEN | DMA_CTL_LLP_DSTEN))
 */
#define DMA_CTL_LLP_DISABLE_LE32 0xffffffe7
#define DMA_CTL_SMS(num)	((num & 0x3) << 25)		/*Src Master Select*/
#define DMA_CTL_DMS(num)	((num & 0x3) << 23)		/*Dst Master Select*/
#define DMA_CTL_TTFC(type)	((type & 0x7) << 20)	/*Type&Flow cntr*/
#define DMA_CTL_TTFC_P2M_DMAC	2			/*Per mem,DMAC cntr*/
#define DMA_CTL_TTFC_M2P_PER	3			/*Mem per,peri cntr*/
#define DMA_CTL_SRC_MSIZE(size) ((size & 0x7) << 14)	/*Src Burst Len*/
#define DMA_CTL_DST_MSIZE(size)	((size & 0x7) << 11)	/*Dst Burst Len*/
#define DMA_CTL_SINC_INC	0x00000000				/*Src addr incr*/
#define DMA_CTL_SINC_DEC	0x00000200
#define DMA_CTL_SINC_NOCHANGE	0x00000400
#define DMA_CTL_DINC_INC	0x00000000				/*Dst addr incr*/
#define DMA_CTL_DINC_DEC	0x00000080
#define DMA_CTL_DINC_NOCHANGE	0x00000100
#define DMA_CTL_SRC_TRWID(size)	((size & 0x7) << 4)	/*Src Trnsfr Width*/
#define DMA_CTL_DST_TRWID(size)	((size & 0x7) << 1)	/*Dst Trnsfr Width*/
#define DMA_CTL_INT_EN		0x00000001				/*Interrupt Enable*/

/* Bitfields in CTL_LO */
#define DWC_CTLL_INT_EN			(1 << 0)	// irqs enabled?
#define DWC_CTLL_DST_WIDTH(n)	((n & 0x7) << 1)	// bytes per element
#define DWC_CTLL_SRC_WIDTH(n)	((n & 0x7) << 4)
#define DWC_CTLL_DST_INC		(0<<7)		// DAR update/not
#define DWC_CTLL_DST_DEC		(1<<7)
#define DWC_CTLL_DST_FIX		(2<<7)
#define DWC_CTLL_SRC_INC		(0<<9)		// SAR update/not
#define DWC_CTLL_SRC_DEC		(1<<9)
#define DWC_CTLL_SRC_FIX		(2<<9)
#define DWC_CTLL_DST_MSIZE(n)	((n)<<11)	// burst, #elements */
#define DWC_CTLL_SRC_MSIZE(n)	((n)<<14)
#define DWC_CTLL_S_GATH_EN		(1 << 17)	// src gather, !FIX */
#define DWC_CTLL_D_SCAT_EN		(1 << 18)	// dst scatter, !FIX */
#define DWC_CTLL_FC(n)			((n) << 20)
#define DWC_CTLL_FC_M2M			(0 << 20)	// SATA DMA mem-to-mem
#define DWC_CTLL_FC_M2P			(1 << 20)	// SATA DMA mem-to-periph
#define DWC_CTLL_FC_P2M			(2 << 20)	// SATA DMA periph-to-mem
#define DWC_CTLL_FC_P2P			(3 << 20)	// SATA DMA periph-to-periph
/* plus 4 transfer types for peripheral-as-flow-controller */
#define DWC_CTLL_DMS(n)			((n)<<23)	// dst master select
#define DWC_CTLL_SMS(n)			((n)<<25)	// src master select
#define DWC_CTLL_LLP_D_EN		(1 << 27)	// dest block chain
#define DWC_CTLL_LLP_S_EN		(1 << 28)	// src block chain
#define DWC_CTLL_LLP_CLR_LE32	0xffffffe7	// clear S_EN & D_EN in LE32
#define	DWC_CTLL_INT_EN_LE32	0x01000000	// enable innterrupt in LE32
/* Bitfields in CTL_HI */
#define DWC_CTLH_DONE		0x00001000
#define DWC_CTLH_BLOCK_TS_MASK	0x00000fff

/* Bitfields in CFG_HI */
#define DWC_CFGH_FCMODE		(1 << 0)		// Flow Control Mode
#define DWC_CFGH_FIFO_MODE	(1 << 1)
#define DWC_CFGH_PROTCTL(x)	((x) << 2)		// Protection control
#define DWC_CFGH_DS_UPD_EN	(1 << 5)
#define DWC_CFGH_SS_UPD_EN	(1 << 6)
#define DWC_CFGH_SRC_PER(x)	((x) << 7)
#define DWC_CFGH_DST_PER(x)	((x) << 11)

/* Bitfields in CFG_LO */
#define DWC_CFGL_CH_PRIOR_MASK	(0x7 << 5)	// priority mask
#define DWC_CFGL_CH_PRIOR(x)	((x) << 5)	// channel priority
#define DWC_CFGL_CH_SUSP	(1 << 8)		// pause xfer
#define DWC_CFGL_FIFO_EMPTY	(1 << 9)		// fifo emppty
#define DWC_CFGL_HS_DST		(1 << 10)		// handshake w/dst
#define DWC_CFGL_HS_SRC		(1 << 11)		// handshake w/src
#define DWC_CFGL_LOCK_CH_XFER	(0 << 12)	// scope of LOCK_CH
#define DWC_CFGL_LOCK_CH_BLOCK	(1 << 12)
#define DWC_CFGL_LOCK_CH_XACT	(2 << 12)
#define DWC_CFGL_LOCK_BUS_XFER	(0 << 14)	// scope of LOCK_BUS
#define DWC_CFGL_LOCK_BUS_BLOCK	(1 << 14)
#define DWC_CFGL_LOCK_BUS_XACT	(2 << 14)
#define DWC_CFGL_LOCK_CH	(1 << 15)		// channel lockout
#define DWC_CFGL_LOCK_BUS	(1 << 16)		// busmaster lockout
#define DWC_CFGL_HS_DST_POL	(1 << 18)		// dst handshake active low
#define DWC_CFGL_HS_SRC_POL	(1 << 19)		// src handshake active low
#define DWC_CFGL_MAX_BURST(x)	((x) << 20)
#define DWC_CFGL_RELOAD_SAR	(1 << 30)
#define DWC_CFGL_RELOAD_DAR	(1 << 31)

/* Bitfields in StatusInt */
#define DWC_STATUSINT_XFER	(1 << 0)		// Combined status TFR
#define DWC_STATUSINT_BLOCK	(1 << 1)		// Combined status Block
#define DWC_STATUSINT_ERR	(1 << 4)		// Combined status TFR

/* Channel Configuration Register low bits */
#define DMA_CFG_RELD_DST	0x80000000				/*Reload Dst/Src Addr*/
#define DMA_CFG_RELD_SRC	0x40000000
#define DMA_CFG_HS_SELSRC	0x00000800				/*SW hndshk Src/Dst*/
#define DMA_CFG_HS_SELDST	0x00000400
#define DMA_CFG_FIFOEMPTY   (0x00000001 << 9)	/*FIFO Empty bit*/
#define DMA_CFG_DST_BURST_ALIGN	(1 << 0)	/* dst burst align */
#define DMA_CFG_SRC_BURST_ALIGN	(1 << 1)	/* src burst align */

/* Assign hardware handshaking interface (x) to dst / sre peripheral */
#define DMA_CFG_HW_HS_DEST(int_num)	((int_num & 0xF) << 11)
#define DMA_CFG_HW_HS_SRC(int_num)	((int_num & 0xF) << 7)

/* Channel Linked List Pointer Register */
#define DMA_LLP_LMS(addr, master)	(((addr) & 0xfffffffc) | (master))
#define DMA_LLP_AHBMASTER1		0	/* List Master Select */
#define DMA_LLP_AHBMASTER2		1

#define SATA_DWC_MAX_PORTS	1

#define SATA_DWC_SCR_OFFSET	0x24
#define SATA_DWC_REG_OFFSET	0x64

/* DWC SATA Registers */
struct sata_dwc_regs {
	u32 fptagr;		/* 1st party DMA tag */
	u32 fpbor;		/* 1st party DMA buffer offset */
	u32 fptcr;		/* 1st party DMA Xfr count */
	u32 dmacr;		/* DMA Control */
	u32 dbtsr;		/* DMA Burst Transaction size */
	u32 intpr;		/* Interrupt Pending */
	u32 intmr;		/* Interrupt Mask */
	u32 errmr;		/* Error Mask */
	u32 llcr;		/* Link Layer Control */
	u32 phycr;		/* PHY Control */
	u32 physr;		/* PHY Status */
	u32 rxbistpd;	/* Recvd BIST pattern def register */
	u32 rxbistpd1;	/* Recvd BIST data dword1 */
	u32 rxbistpd2;	/* Recvd BIST pattern data dword2 */
	u32 txbistpd;	/* Trans BIST pattern def register */
	u32 txbistpd1;	/* Trans BIST data dword1 */
	u32 txbistpd2;	/* Trans BIST data dword2 */
	u32 bistcr;		/* BIST Control Register */
	u32 bistfctr;	/* BIST FIS Count Register */
	u32 bistsr;		/* BIST Status Register */
	u32 bistdecr;	/* BIST Dword Error count register */
	u32 res[15];	/* Reserved locations */
	u32 testr;		/* Test Register */
	u32 versionr;	/* Version Register */
	u32 idr;		/* ID Register */
	u32 unimpl[192];/* Unimplemented */
	u32 dmadr[256];	/* FIFO Locations in DMA Mode */
};

#define SCR_SCONTROL_DET_ENABLE		0x00000001
#define SCR_SSTATUS_DET_PRESENT		0x00000001
#define SCR_CLEAR_INTPR_DIAG_X		0x04000000

/* DWC SATA Register Operations */
#define	SATA_DWC_TXFIFO_DEPTH		0x01FF
#define	SATA_DWC_RXFIFO_DEPTH		0x01FF

#define SATA_DWC_DMACR_TXMODE		0x00000004	// Always use transmit mode 1
#define	SATA_DWC_DMACR_TXCHEN		(0x00000001 | SATA_DWC_DMACR_TXMODE)
#define	SATA_DWC_DMACR_RXCHEN		(0x00000002 | SATA_DWC_DMACR_TXMODE)

#define SATA_DWC_DBTSR_MWR(size)	((size>>2) & SATA_DWC_TXFIFO_DEPTH)
#define SATA_DWC_DBTSR_MRD(size)	(((size>>2) & SATA_DWC_RXFIFO_DEPTH) << 16)

// SATA DWC Interrupts
#define	SATA_DWC_INTPR_DMAT			0x00000001
#define SATA_DWC_INTPR_NEWFP		0x00000002
#define SATA_DWC_INTPR_PMABRT		0x00000004
#define SATA_DWC_INTPR_ERR			0x00000008
#define SATA_DWC_INTPR_NEWBIST		0x00000010
#define SATA_DWC_INTPR_IPF			0x80000000
// Interrupt masks
#define	SATA_DWC_INTMR_DMATM		0x00000001
#define SATA_DWC_INTMR_NEWFPM		0x00000002
#define SATA_DWC_INTMR_PMABRTM		0x00000004
#define SATA_DWC_INTMR_ERRM			0x00000008
#define SATA_DWC_INTMR_NEWBISTM		0x00000010
#define SATA_DWC_INTMR_PRIMERRM		0x00000020
#define SATA_DWC_INTPR_CMDGOOD		0x00000080
#define SATA_DWC_INTPR_CMDABORT		0x00000040

#define SATA_DWC_LLCR_SCRAMEN		0x00000001
#define SATA_DWC_LLCR_DESCRAMEN		0x00000002
#define SATA_DWC_LLCR_RPDEN			0x00000004

// Defines for serror register
#define SATA_DWC_SERR_ERRI      0x00000001 // Recovered data integrity error
#define SATA_DWC_SERR_ERRM      0x00000002 // Recovered communication error
#define SATA_DWC_SERR_ERRT      0x00000100 // Non-recovered transient data integrity error
#define SATA_DWC_SERR_ERRC      0x00000200 // Non-recovered persistent communication or data integrity error
#define SATA_DWC_SERR_ERRP      0x00000400 // Protocol error
#define SATA_DWC_SERR_ERRE      0x00000800 // Internal host adapter error
#define SATA_DWC_SERR_DIAGN     0x00010000 // PHYRdy change
#define SATA_DWC_SERR_DIAGI     0x00020000 // PHY internal error
#define SATA_DWC_SERR_DIAGW     0x00040000 // Phy COMWAKE signal is detected
#define SATA_DWC_SERR_DIAGB     0x00080000 // 10b to 8b decoder err
#define SATA_DWC_SERR_DIAGT     0x00100000 // Disparity error
#define SATA_DWC_SERR_DIAGC		0x00200000 // CRC error
#define SATA_DWC_SERR_DIAGH		0x00400000 // Handshake error
#define SATA_DWC_SERR_DIAGL		0x00800000 // Link sequence (illegal transition) error
#define SATA_DWC_SERR_DIAGS		0x01000000 // Transport state transition error
#define SATA_DWC_SERR_DIAGF		0x02000000 // Unrecognized FIS type
#define SATA_DWC_SERR_DIAGX		0x04000000 // Exchanged error - Set when PHY COMINIT signal is detected.
#define SATA_DWC_SERR_DIAGA		0x08000000 // Port Selector Presence detected

/* This is all error bits, zero's are reserved fields. */
#define SATA_DWC_SERR_ERR_BITS	0x0FFF0F03

#define SATA_DWC_SCR0_SPD_GET(v)	(((v) >> 4) & 0x0000000F)
#define SATA_DWC_DMACR_TX_CLEAR(v)	(((v) & ~SATA_DWC_DMACR_TXCHEN)| SATA_DWC_DMACR_TXMODE)
#define SATA_DWC_DMACR_RX_CLEAR(v)	(((v) & ~SATA_DWC_DMACR_RXCHEN)| SATA_DWC_DMACR_TXMODE)
#define SATA_DWC_DMACR_TXRXCH_CLEAR	SATA_DWC_DMACR_TXMODE // Always use transmit mode 1

/* SATA DWC registers can be set via ap->ioaddr or hsdev->sata_dwc_regs */
struct sata_dwc_device {
	struct 	device *dev;		/* generic device struct */
	struct 	ata_probe_ent *pe;	/* ptr to probe-ent */
	struct 	ata_host *host;
	struct 	sata_dwc_regs __iomem *sata_dwc_regs;	/* DW Synopsys SATA specific */
	struct 	resource reg;       /* Resource for register */
	u8		__iomem *reg_base;
	u8     	*scr_base;
	int		dma_channel;		/* DWC SATA DMA channel  */
	int		irq_dma;
	struct	timer_list an_timer;
};

#define SATA_DWC_QCMD_MAX	32

struct sata_dwc_device_port {
	struct 	sata_dwc_device	*hsdev;
	int		cmd_issued[SATA_DWC_QCMD_MAX]; 	// QC issued
	int		dma_pending[SATA_DWC_QCMD_MAX]; // DMA command needs to be processed
//	u32		dma_chan[SATA_DWC_QCMD_MAX]; 	// Consider to be removed
	struct	lli *llit[SATA_DWC_QCMD_MAX]; 	// NCQ
	dma_addr_t llit_dma[SATA_DWC_QCMD_MAX];
	int		num_lli[SATA_DWC_QCMD_MAX];
	u32 	sactive_issued;				/* issued queued ops */
	u32 	sactive_queued;				/* queued ops */
	u32		dma_dir;					// DMA direction bitmask for each tag (0=read, 1=write)
	u32		dma_complete; 				// tasks completes DMA transfer
	int		no_dma_pending; 			// Number of pending DMA
	int		dma_pending_isr_count; 		// Number of interrupt count
	int		max_tag; 					// maximum tag, used for debug NCQ only
};

/* Commonly used DWC SATA driver Macros */
#define HSDEV_FROM_HOST(host)	((struct sata_dwc_device *) (host)->private_data)
#define HSDEV_FROM_AP(ap)		((struct sata_dwc_device *) (ap)->host->private_data)
#define HSDEVP_FROM_AP(ap)		((struct sata_dwc_device_port *) (ap)->private_data)
#define HSDEV_FROM_QC(qc)		((struct sata_dwc_device *) (qc)->ap->host->private_data)
#define HSDEV_FROM_HSDEVP(p) 	((struct sata_dwc_device *) (p)->hsdev)
#define IOMEM(x) (void __iomem *)(x)

#undef BIT
#define BITFIELD(x)		char _#x 
#define BIT(b)			(0x00000001 << (b))  //defined in linux/bitops.h
#define BITS(n,b)		((0x00000000 | (n)) << (b))
#define BITRANGE(n,b)	((0x00000000 |
#define SETB(x,b) 		((x) |= BIT(b))
#define SETBS(x,n,b) 	((x) != BITS(n,b))
#define CLRB(x,b) 		((x) &=~BIT(b))
#define CLRBS(x,b) 		((x) &=~BITS(n,b))
#define REVB(x,b) 		((x) ^= BIT(b))
#define TSETB(x,b) 		((x) & (1<<(b)))
#define TCLRB(x,b) 		(((x)>>(b))&1)

#define TAG2MASK(tag)			((u32)(0x00000001 << (tag & 0x1f)))
#define DMA_DIR_SET_READ(var,tag)	var &= ~((u32)(0x00000001 << (tag & 0x1f)))
#define DMA_DIR_SET_WRITE(var,tag)	var |= ((u32)(0x00000001 << (tag & 0x1f)))
#define DMA_DIR_GET(var,tag) 	((var) & (1<<(tag & 0x1f)))
#define DMA_PENDING_SET(var,tag) 	var |= ((u32)(0x00000001 << (tag & 0x1f)))
#define DMA_PENDING_CLEAR(var,tag) 	var &= ~((u32)(0x00000001 << (tag & 0x1f)))
#define DMA_PENDING_GET(var,tag)	((var) & (1<<(tag & 0x1f)))

enum {
	SATA_DWC_CMD_ISSUED_NOT		= 0,
	SATA_DWC_CMD_ISSUED_PENDING	= 1,
	SATA_DWC_CMD_ISSUED_EXEC	= 2,
	SATA_DWC_CMD_ISSUED_DONE	= 3,

	SATA_DWC_DMA_PENDING_NONE	= 0,
	SATA_DWC_DMA_PENDING_TX		= 1,
	SATA_DWC_DMA_PENDING_RX		= 2,
	SATA_DWC_DMA_PENDING		= 3,
	SATA_DWC_DMA_DONE			= 4,  // NCQ
};

/* Prototypes */
static __always_inline void sata_dwc_bmdma_start_by_tag(struct ata_queued_cmd *qc, u8 tag);
static __always_inline void sata_dwc_qc_complete(struct ata_port *ap, struct ata_queued_cmd *qc, u8 tag, u32 check_status);
static void sata_dwc_port_stop(struct ata_port *ap);
static __always_inline int dma_init(struct sata_dwc_device *hsdev);
static __always_inline void dma_exit(struct sata_dwc_device *hsdev);
static void dma_dwc_terminate_dma(struct ata_port *ap, int dma_ch);
static __always_inline void sata_dwc_enable_interrupts(struct sata_dwc_regs __iomem *regs);
static void sata_dwc_init_port (struct ata_port *ap);

u8 sata_dwc_check_status(struct ata_port *ap);
#define SATA_DWC_CHECK_STATUS(ap) (u8)ioread8(ap->ioaddr.status_addr)
#define SATA_DWC_IRQ_CLEAR(bmdma_addr) iowrite8(ioread8(bmdma_addr), bmdma_addr)
char *u32ToBits(u32 val){
    static char bitstr[] = "0000:0000:0000:0000:0000:0000:0000:0000\0", *cp = bitstr;
	int i, j;
	for (i=0; i<8; i++, cp++)
		for (j=0; j<4; j++, cp++)  { *cp = (val & 0x80000000)?'1':'0'; val <<= 1; }
//	return bitstr;
	return memcpy(kmalloc(40,GFP_KERNEL), bitstr, 40);
}
static int sata_dwc_scr_read(struct ata_link *link, unsigned int scr, u32 *val) {
	register struct ata_port *ap = link->ap;
	if (unlikely(scr > SCR_NOTIFICATION)) {
		dev_err(ap->dev, "%s: Incorrect SCR offset 0x%02x\n",	__func__, scr);
		return -EINVAL;
	}
	*val = in_le32((void __iomem *)ap->ioaddr.scr_addr + (scr * 4));
	dwc_dev_vdbg(ap->dev, "%s: id=%d reg=%s val=0x%08x\n", __func__, ap->print_id, sata_reg2txt(scr), *val);
	return 0;
}

static int sata_dwc_scr_write(struct ata_link *link, unsigned int scr, u32 val) {
	register struct ata_port *ap = link->ap;
	dwc_dev_vdbg(ap->dev, "%s: id=%d reg=%s val=0x%08x\n",__func__, ap->print_id, sata_reg2txt(scr), val);
	if (unlikely(scr > SCR_NOTIFICATION)) {
		dev_err(ap->dev, "%s: Incorrect SCR offset 0x%02x\n",	__func__, scr);
		return -EINVAL;
	}
	out_le32((void __iomem *)ap->ioaddr.scr_addr + (scr << 2), val);	
	return 0;
}

#define SATA_DWC_CORE_SCR_READ(hsdev,scr) in_le32((void __iomem *)hsdev->scr_base + (scr<<2))
/*
static inline u32 sata_dwc_core_scr_read (struct ata_port *ap, unsigned int scr)
{
	struct sata_dwc_device *hsdev = HSDEV_FROM_AP(ap);
	return in_le32((void __iomem *)hsdev->scr_base + (scr * 4));
}
*/
#define SATA_DWC_CORE_SCR_WRITE(hsdev,scr,val) out_le32((void __iomem *)hsdev->scr_base + (scr<<2), val)
/*
static inline void sata_dwc_core_scr_write (struct ata_port *ap, unsigned int scr, u32 val)
{
	struct sata_dwc_device *hsdev = HSDEV_FROM_AP(ap);
	out_le32((void __iomem *)hsdev->scr_base + (scr * 4), val);
}
*/
#define SATA_DWC_CORE_SCR_SETBIT(dev,reg,b) SATA_DWC_CORE_SCR_WRITE(dev, reg ,\
	(SATA_DWC_CORE_SCR_READ(dev,reg) | (b)))

#ifdef CONFIG_SATA_DWC_DEBUG
//ata_eh_link_report(struct ata_link *link)  may make these unneeded
/* Convert QC protocol to text */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
static const char *prot2txt(enum ata_tf_protocols protocol) {
#else
static const char *prot2txt(enum ata_prot_flags protocol) {
#endif
	switch (protocol) {
		case ATA_PROT_UNKNOWN:	return "unknown";
		case ATA_PROT_NODATA:	return "nodata";
		case ATA_PROT_PIO:		return "ATA PIO";
		case ATA_PROT_DMA:		return "ATA DMA";
		case ATA_PROT_NCQ:		return "ATA NCQ";
		case ATAPI_PROT_NODATA: return "ATAPI no data";
		case ATAPI_PROT_PIO:	return "ATAPI PIO";
		case ATAPI_PROT_DMA:	return "ATAPI DMA";
		default:				return "err";
	}
}

/* Convert DMA direction to text */
static const char *dir2txt(enum dma_data_direction dir) {
	switch (dir) {
		case DMA_BIDIRECTIONAL:	return "Bidirectional";
		case DMA_TO_DEVICE:		return "ToDevice";
		case DMA_FROM_DEVICE:	return "FromDevice";
		case DMA_NONE:			return "None";
		default:				return "Error";
	}
}
#endif

/* Convert serror register bits to text */
static void print_serror2txt (u32 serror) {
	printk("Detect errors (0x%08x):", serror);
	if (serror & SATA_DWC_SERR_ERRI) printk(" ERRI");
	if (serror & SATA_DWC_SERR_ERRM) printk(" ERRM");
	if (serror & SATA_DWC_SERR_ERRT) printk(" ERRT");
	if (serror & SATA_DWC_SERR_ERRC) printk(" ERRC");
	if (serror & SATA_DWC_SERR_ERRP) printk(" ERRP");
	if (serror & SATA_DWC_SERR_ERRE) printk(" ERRE");
	if (serror & SATA_DWC_SERR_DIAGN) printk(" DIAGN");
	if (serror & SATA_DWC_SERR_DIAGI) printk(" DIAGI");
	if (serror & SATA_DWC_SERR_DIAGW) printk(" DIAGW");
	if (serror & SATA_DWC_SERR_DIAGB) printk(" DIAGB");
	if (serror & SATA_DWC_SERR_DIAGT) printk(" DIAGT");
	if (serror & SATA_DWC_SERR_DIAGC) printk(" DIAGC");
	if (serror & SATA_DWC_SERR_DIAGH) printk(" DIAGH");
	if (serror & SATA_DWC_SERR_DIAGL) printk(" DIAGL");
	if (serror & SATA_DWC_SERR_DIAGS) printk(" DIAGS");
	if (serror & SATA_DWC_SERR_DIAGF) printk(" DIAGF");
	if (serror & SATA_DWC_SERR_DIAGX) printk(" DIAGX");
	if (serror & SATA_DWC_SERR_DIAGA) printk(" DIAGA");
	printk("\n");
}

/* Convert SATA command to text */
// replaced by ata_get_cmd_descript
const char *ata_get_cmd_descript(u8 command);
#define cmd2txt(x) ata_get_cmd_descript((x)->command)

#ifdef CONFIG_SATA_DWC_VDEBUG
/* Dump content of the taskfile */
static void sata_dwc_tf_dump(struct device *dwc_dev, struct ata_taskfile *tf) {
	dwc_dev_vdbg(dwc_dev, "taskfile cmd:0x%02x protocol:%s flags:0x%lx device:%x\n",
		tf->command, prot2txt(tf->protocol), tf->flags, tf->device);
	dwc_dev_vdbg(dwc_dev, "feature:0x%02x nsect:0x%x lbal: 0x%x lbam:0x%x lbah:0x%x\n",
		tf->feature, tf->nsect, tf->lbal, tf->lbam, tf->lbah);
	dwc_dev_vdbg(dwc_dev, "hob_feature:0x%02x hob_nsect:0x%x hob_lbal:0x%x hob_lbam:0x%x hob_lbah:0x%x\n",
		tf->hob_feature, tf->hob_nsect, tf->hob_lbal, tf->hob_lbam,	tf->hob_lbah);
}

/* Convert SATA Control and Status registers to text */
static const char* sata_reg2txt(unsigned int id) {
	switch (id) {
		case SCR_STATUS:		return "SCR_STATUS";
	case SCR_ERROR:		return "SCR_ERROR";
		case SCR_CONTROL:		return "SCR_CONTROL";
		case SCR_NOTIFICATION:	return "SCR_NOTIFICATION";
		default:				return "err";
	}
}

/* Print out current setting of the DMA configuration by reading DMA registers */
#define in_cpu32(x) 		le32_to_cpu(in_le32(x))
#define in_cpu32_bits(x) 	u32ToBits(in_cpu32(x))
#define	in_le32_bits(x) 	u32ToBits(in_le32(x))
static void print_dma_registers(struct sata_dwc_device *hsdev) {
	int dma_chan = hsdev->dma_channel;
	struct dmaChanRegs __iomem *chanReg = &(sata_dma_regs->chan_regs[dma_chan]);
	struct sata_dwc_regs __iomem *dwc_regs = hsdev->sata_dwc_regs;
	printk("Content of DMA registers in channel %d:\n", dma_chan);
	printk("\t- cfg.low 		: 0x%08x\n", in_le32(&chanReg->cfg.low));
	printk("\t- cfg.high		: 0x%08x\n", in_le32(&chanReg->cfg.high));
	printk("\t- ctl.low 		: 0x%08x\n", in_le32(&chanReg->ctl.low));
	printk("\t- ctl.high		: 0x%08x\n", in_le32(&chanReg->ctl.high));
	printk("\t- llp.low 		: 0x%08x\n", in_cpu32(&chanReg->llp.low));
	printk("\t- sar.low 		: 0x%08x\n", in_cpu32(&chanReg->sar.low));
	printk("\t- sar.high		: 0x%08x\n", in_cpu32(&chanReg->sar.high));
	printk("\t- dar.low 		: 0x%08x\n", in_cpu32(&chanReg->dar.low));
	printk("\t- dar.high		: 0x%08x\n", in_cpu32(&chanReg->dar.high));
	printk("\t- sgr.low 		: 0x%08x\n", in_cpu32(&chanReg->sgr.low));
	printk("\t- dma_cfg.low		: 0x%08x\n", in_le32(&sata_dma_regs->dma_cfg.low));;
	printk("\t- dma_chan_en.low	: 0x%08x\n", in_le32(&sata_dma_regs->dma_chan_en.low));;
	printk("\t- INTPR			: 0x%08x\n", in_le32(&dwc_regs->intpr));
	printk("\t- INTMR			: 0x%08x\n", in_le32(&dwc_regs->intmr));
	printk("\t- ERRMR			: 0x%08x\n", in_le32(&dwc_regs->errmr));
	printk("\t- SERROR 			: 0x%08x\n", SATA_DWC_CORE_SCR_READ(hsdev, SCR_ERROR));
	printk("\t- IRR_MASK.ERR	: 0x%08x\n", in_le32(&sata_dma_regs->interrupt_mask.error.low));
	printk("\t- IRR_MASK.TFR	: 0x%08x\n", in_le32(&sata_dma_regs->interrupt_mask.tfr.low));
	printk("\t- IRR_STAT.ERR	: 0x%08x\n", in_le32(&sata_dma_regs->interrupt_status.error.low));
	printk("\t- IRR_STAT.TFR	: 0x%08x\n", in_le32(&sata_dma_regs->interrupt_status.tfr.low));
	printk("\t- CH_EN.low		: 0x%08x\n", in_le32(&sata_dma_regs->dma_chan_en.low));
/*
	printk("\t- cfg.low 		: 0b%s\n", 	 in_le32_bits(&chanReg->cfg.low));
	printk("\t- cfg.high		: 0b%s\n",   in_le32_bits(&chanReg->cfg.high));
	printk("\t- ctl.low			: 0b%s\n",   in_le32_bits(&chanReg->ctl.low));
	printk("\t- ctl.high		: 0b%s\n",   in_le32_bits(&chanReg->ctl.high));
	printk("\t- llp.low 		: 0x%08x\n", in_cpu32(&chanReg->llp.low));
	printk("\t- sar.low 		: 0x%08x\n", in_cpu32(&chanReg->sar.low));
	printk("\t- sar.high		: 0x%08x\n", in_cpu32(&chanReg->sar.high));
	printk("\t- dar.low 		: 0x%08x\n", in_cpu32(&chanReg->dar.low));
	printk("\t- dar.high		: 0x%08x\n", in_cpu32(&chanReg->dar.high));
	printk("\t- sgr.low 		: 0x%08x\n", in_cpu32(&chanReg->sgr.low));
	printk("\t- INTPR			: 0b%s\n",   in_le32_bits(&dwc_regs->intpr));
	printk("\t- INTMR			: 0b%s\n",   in_le32_bits(&dwc_regs->intmr));
	printk("\t- ERRMR			: 0b%s\n",   in_le32_bits(&dwc_regs->errmr));
	printk("\t- SERROR			: 0x%08x\n", SATA_DWC_CORE_SCR_READ(hsdev, SCR_ERROR));
	printk("\t- IRR_MASK.ERR	: 0b%s\n",   in_le32_bits(&sata_dma_regs->interrupt_mask.error.low));
	printk("\t- IRR_MASK.TFR	: 0b%s\n",   in_le32_bits(&sata_dma_regs->interrupt_mask.tfr.low));
	printk("\t- IRR_STAT.ERR	: 0b%s\n",   in_le32_bits(&sata_dma_regs->interrupt_status.error.low));
	printk("\t- IRR_STAT.TFR	: 0b%s\n",   in_le32_bits(&sata_dma_regs->interrupt_status.tfr.low));
*/
}

/* Print out DMA information set up in LLI */
static void print_dma_config(struct ata_port *ap, struct lli *lli, int idx) {
	printk("SATA DWC Port DMA configuration\n");
	printk("index %d\n", idx);
	dwc_port_vdbg(ap, "%s: index %d\n", __func__, idx);
	dwc_port_vdbg(ap, "%s - lli[%d].ctl.high: 0x%08x\n", __func__, idx, lli->ctl.high);
	dwc_port_vdbg(ap, "%s - lli[%d].ctl.low : 0x%08x\n", __func__, idx, lli->ctl.low);
	dwc_port_vdbg(ap, "%s - lli[%d].lli.dar : 0x%08x\n", __func__, idx, lli->dar);
	dwc_port_vdbg(ap, "%s - lli[%d].lli.sar : 0x%08x\n", __func__, idx, lli->sar);
	dwc_port_vdbg(ap, "%s - lli[%d].next_llp: 0x%08x\n", __func__, idx, lli->llp);
}
#endif
/*
 * Function: get_burst_length_encode
 * arguments: datalength: length in bytes of data
 * returns value to be programmed in register corresponding to data length
 * This value is effectively the log(base 2) of the length
 */
/*
static inline int get_burst_length_encode(int datalength) {
	int items = datalength >> 2;	// div by 4 to get lword count
	if (items >= 64)	return 5;
	if (items >= 32)	return 4;
	if (items >= 16)	return 3;
	if (items >= 8)		return 2;
	if (items >= 4)		return 1;
	return 0;
}
*/
